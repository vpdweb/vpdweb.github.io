package com.example;

/*
 *  NAME: 
 *  EMAIL (on iLearn):
 * 
 */

public class Assignment2 {

	/*
	 * Assignment2 task covers two things: Arrays and For Loops.
	 * 
	 * You should ONLY write code in the five methods: searchForValue, findStudentsNumber, 
	 * swapArray, arraySwapBasedOnIndex, and replaceAllSmallerValues
	 * 
	 * Do NOT change the method definitions, or anything in the main method
	 * 
	 * The expected output is at the bottom of the file
	 * 
	 * 
	 * Hints: 
	 * 
	 * 1. To complete this assignment you need to use loops and if statement 
	 * 
	 * 2. Since arrays are indexed (the elements are counted) from 0 the first number is at index 0
	 *    int firstNumber = numberArray[0];
	 *    This also means that the last number is not at array.length because if the array has 10 elements
	 *    then the first element has index 0 so the last element must have index 9
	 *    
	 * 3. To look at every element in an array you need to use for loop
	 *	  for (int i = 0; i < array.length; i++) {
	 *		// Inside the loop you can check each the element and gets its value
	 *      // That means you can do any manipulation with the array element here
	 *	  }  
	 *
	 * 4. Any time you type return the method stops and returns, 
	 *    you can use more that one return in one method
	 * 
	 */

	public static void main(String[] args) {

		String[] courseNames = new String[] { "Programming", "Database", "HCI", "Network", "Security", "Mathematics", "AI" };
		int[] studentsInCourse = new int[] { 30, 25, 35, 40, 50, 20, 47 };

		//Print the arrays
		System.out.println("Print arrays: ");
		printArray(courseNames);
		printArray(studentsInCourse);
		System.out.println();
		
		//Find number of students in a course
		System.out.println("Number of Students in the Programming course: " + findStudentsNumber(courseNames,studentsInCourse, "Programming"));
		System.out.println("Number of Students in AI course: " + findStudentsNumber(courseNames,studentsInCourse, "AI"));
		System.out.println("Number of Students in Network course: " + findStudentsNumber(courseNames, studentsInCourse, "Network"));
		System.out.println();
		
		
		System.out.println("There is at least one course that has 40 students: " + searchForValue(studentsInCourse, 40));
		System.out.println("There is at least one course that has 10 students: " + searchForValue(studentsInCourse, 10));
		System.out.println();
		
		//Swap the first element with the last element 
		swapArray(courseNames);
		System.out.println();
	
		//Swap the first element and the element at targetIndex for both arrays
		System.out.println("Swap based on Index: ");
		arraySwapBasedOnIndex(studentsInCourse, courseNames, 5);
		System.out.println();
	
		replaceAllSmallerValues(studentsInCourse, 30, 35);
	
	}
	

	
	public static boolean searchForValue(int[] studentsArray, int value1) {

		// Return TRUE if numberArray contains value1

		// We use a for loop to traverse the array and an if-else statement
		// to check for given condition
		for (int i = 0; i < studentsArray.length; i++) {
			if (studentsArray[i] == value1) {
				return true; // last return statement never gets executed
			}
		}

		// Don't change this line:
		return false;
	}
	
	
	public static int findStudentsNumber(String[] coursesArray, int[] studentsArray, String course) {

		// Find the number of the students for the course 

		// Get the index of the value contained in the `course` parameter
		// using a for loop and an if-else statement to test each value against the
		// given `course` value
		int courseIndex = 0; // will store index of course value for use later
		for (int i = 0; i < coursesArray.length; i++) {
			if (coursesArray[i] == course) {
				courseIndex = i;
				return studentsArray[courseIndex];
			}
		}

		// Don't change this line:
		return 0;
		
	}
	
	
	
	public static void swapArray(String[] coursesArray) {

		// 1. Swap the last and first elements of this array
		// 2. Then make the second element the same as
		// the first element of the array

		// We will use temportary variable to hold value of first element
		String firstElemTmp = coursesArray[0];
		// Assign last element to first element
		coursesArray[0] = coursesArray[coursesArray.length - 1];
		// Assign original value of first element to last element
		coursesArray[coursesArray.length - 1] = firstElemTmp;
		// Finally, make second element same as first element
		coursesArray[1] = coursesArray[0];


		// Don't change these two lines:
		System.out.println("Swapping the first element with the last element:");
		printArray(coursesArray);

	}

	
	public static void arraySwapBasedOnIndex(int[] studentsArray, String[] coursesArray, int targetIndex){
		
		//1. Swap the first element and the element at targetIndex for both arrays.
		//2. Then after the Swap,
		//3. For the numberArray make the element at targetIndex equals to the sum of the first and last elements 
		//4. For the stringArray concatenate the number at targetIndex in numberArray to the string at targetIndex in stringArray
		
		
		// Swap first element and element at targetIndex for studentsArray (the numberArray)
		// Store first element in a temporary variable
		int studentsArrayFirstElemTmp = studentsArray[0];
		// Assign value of element at targetIndex to first element
		studentsArray[0] = studentsArray[targetIndex];
		// Assign value of original first element to element at targetIndex
		studentsArray[targetIndex] = studentsArrayFirstElemTmp;
		// Make element at targetIndex equals to sum of first and last elements
		int studentsArrayFirstElem = studentsArray[0];
		int studentsArrayLastElem = studentsArray[studentsArray.length - 1];
		studentsArray[targetIndex] = studentsArrayFirstElem + studentsArrayLastElem;
		
		// Follow similar steps for coursesArray
		// Store first element in a temporary variable
		String coursesArrayFirstElemTmp = coursesArray[0];
		// Assign value of element at targetIndex to first element
		coursesArray[0] = coursesArray[targetIndex];
		// Assign value of original first element to element at targetIndex
		coursesArray[targetIndex] = coursesArrayFirstElemTmp;
		// Concatenate the number at targetIndex in studentsArray to the string at targetIndex in coursesArray
		int studentsArrayNum = studentsArray[targetIndex]; // number at targetIndex in studentsArray
		String coursesArrayString = coursesArray[targetIndex]; // string at targetIndex in coursesArray
		// concatenate the two into a new string (Integer type should be converted into String type)
		String newString = coursesArrayString + String.valueOf(studentsArrayNum);
		// Assign newString to element at targetIndex in coursesArray
		coursesArray[targetIndex] = newString;


		//Don't change these three lines:
		System.out.println("The result Array After Swapping and manipulating the Arrays: ");
		printArray(coursesArray);
		printArray(studentsArray);
		
	}


	public static void replaceAllSmallerValues(int[] studentsArray, int value, int newValue) {

		// Check every element of numberArray, if the value is less than value1
		// then change it to newValue

		// We use a for loop to traverse the studentsArray, then an if-else statement
		// to check for the given condition and act accordingly
		for (int i = 0; i < studentsArray.length; i++) {
			if (studentsArray[i] < value) {
				studentsArray[i] = newValue;
			}
		}

		// Don't change these two lines:
		System.out.println("replaceAllSmallerValues: " + value + " changed to " + newValue);
		printArray(studentsArray);
	}

	

	// Don't change this method
	public static void printArray(int[] array) {

		for (int i = 0; i < array.length - 1; i++) {
			System.out.print(array[i] + ", ");
		}
		if (array.length > 0) {
			System.out.print(array[array.length - 1]);
		}
		System.out.println();
	}

	// Don't change this method
	public static void printArray(String[] array) {

		for (int i = 0; i < array.length - 1; i++) {
			System.out.print(array[i] + ", ");
		}
		if (array.length > 0) {
			System.out.print(array[array.length - 1]);
		}
		System.out.println();
	}

}


	
/*Expected Output:

	*Print arrays: 
	*Programming, Database, HCI, Network, Security, Mathematics, AI
	*30, 25, 35, 40, 50, 20, 47
	
	*Number of Students in the Programming course: 30
	*Number of Students in AI course: 47
	*Number of Students in Network course: 40
	
	*There is at least one course that has 40 students: true
	*There is at least one course that has 10 students: false
	
	*Swapping the first element with the last element:
	*AI, AI, HCI, Network, Security, Mathematics, Programming
	
	*Swap based on Index: 
	*The result Array After Swapping and manipulating the Arrays: 
	*Mathematics, AI, HCI, Network, Security, Mathematics67, Programming
	*20, 25, 35, 40, 50, 67, 47
	
	*replaceAllSmallerValues: 30 changed to 35
	*35, 35, 35, 40, 50, 67, 47
*/


/* Correction: After the swapping and manipulation operation in step 5 the element at targetIndex in the stringArray is "AI" and not "Mathematics", therefore expected output for that part should be:

*Swap based on Index: 
*The result Array After Swapping and manipulating the Arrays: 
*Mathematics, AI, HCI, Network, Security, AI67, Programming
*20, 25, 35, 40, 50, 67, 47

*/



