				</div>
			</div><!-- .padder -->
		
		</div><!-- #container -->
</section>	
<?php 
get_footer( wplms_modern_get_footer() ); 