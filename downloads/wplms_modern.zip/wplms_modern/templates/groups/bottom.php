</div>	
			</div>	
		</div><!-- #container -->
	</div>	
</section>	
<?php get_footer( wplms_modern_get_footer() ); ?>
