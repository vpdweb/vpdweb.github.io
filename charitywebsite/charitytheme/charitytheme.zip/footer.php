<!-- NEWSLETTER SUBSCRIPTION FORM -->
<div class="widget js-widget">
    <div class="widget__content">

        <div class="subscribe">
            <form action="#" class="subscribe__form js-subscribe-form">
                <h4 class="subscribe__title">Our Newsletter</h4>
                <div class="subscribe__group form-group">
                    <label class="sr-only">Our Newsletter</label>
                    <input type="email" placeholder="Your e-mail" name="email" required data-parsley-trigger="change" class="subscribe__field form-control js-subscribe-email">
                </div>
                <button type="submit" class="btn--action subscribe__submit js-subscribe-submit">SEND</button>
            </form>
        </div>
    </div>
</div>

<!-- FOOTER -->
<footer class="footer">
    <div class="container">
        <div class="footer__wrap">
            <div class="footer__col footer__col--first">
                <div class="widget js-widget widget--footer">
                    <div class="widget__header">
                        <h2 class="widget__title">About Us</h2>
                    </div>
                    <div class="widget__content">
                        <aside class="widget_text">
                            <div class="textwidget">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Provident rerum nam, quo a libero maxime
                                    voluptatum porro ipsam maiores cupiditate? Dolore eligendi, distinctio autem, obcaecati ducimus similique
                                    corporis quia veritatis?</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur laudantium tempore quod veniam magnam
                                    labore nemo saepe minima blanditiis, totam.</p>
                                <p><a href="<?php echo get_site_url(); ?>/">Read more</a></p>
                            </div>

                        </aside>
                    </div>
                </div>
                <div class="widget js-widget widget--footer">
                    <div class="widget__header">
                        <h2 class="widget__title">Follow Us</h2>
                    </div>
                    <div class="widget__content">
                        <div class="social social--footer"><a href="<?php echo get_site_url(); ?>/" class="social__item"><i class="fa fa-facebook"></i></a>
                            <a href="<?php echo get_site_url(); ?>/" class="social__item"><i class="fa fa-twitter"></i></a><a href="<?php echo get_site_url(); ?>/" class="social__item"><i class="fa fa-google-plus"></i></a></div>
                    </div>
                </div>
            </div>
            <div class="footer__col footer__col--second">
                <div class="widget js-widget widget--footer">
                    <div class="widget__header">
                        <h2 class="widget__title">Contact</h2>
                    </div>
                    <div class="widget__content">
                        <section class="address address--footer">
                            <h4 class="address__headline">Our office</h4>
                            <address class="address__main">
                                <span>Lorem ipsum dolor, Building A, Street B, Nairobi CBD</span>
                                <h4 class="address__headline">Working hours</h4>
                                <span>08.00 am - 5.00 pm Mon - Fri</span>
                                <h4 class="address__headline">Phone</h4>
                                <span>+254 0712 345678</span>
                                <span>+254 0712 345678</span>
                                <h4 class="address__headline">E-mail</h4><span>
                      <a href="mailto:info@charitywebsite.or.ke">info@charitywebsite.or.ke</a></span></address>
                        </section>
                    </div>
                </div>
            </div>

            <div class="footer__col footer__col--third">
                <div class="widget js-widget widget--footer">
                    <div class="widget__header">
                        <h2 class="widget__title">Feedback</h2>
                    </div>
                    <div class="widget__content">
                        <form action="#" class="form form--flex form--footer js-parsley">
                            <div class="row">
                                <div class="form-group">
                                    <label for="in-email" class="sr-only control-label">E-mail</label>
                                    <input id="in-email" type="email" name="email" placeholder="E-mail" required data-parsley-trigger="change" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="in-message" class="sr-only control-label">Your message</label>
                                    <textarea id="in-message" name="message" placeholder="Your message" required data-parsley-trigger="keyup" data-parsley-minlength="20"
                                              data-parsley-validation-threshold="10" data-parsley-minlength-message="You need to enter at least a 20-character long message.."
                                              class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <button type="submit" class="form__submit">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="clearfix"></div><span class="footer__copyright">&copy; 2017 Charity Website. All rights reserved</span>
        </div>

    </div>
</footer>

</div>
</div>

<!-- SCROLL UP BUTTON: revealed on page scroll down limit , removed on page scroll up limit -->
<button type="button" class="scrollup js-scrollup"></button>

<?php wp_footer(); ?>

</body>

</html>