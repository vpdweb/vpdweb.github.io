<?php /* Template Name: home */ get_header(); ?>

<!-- MAIN CONTENT AREA: sections organised into components / widgets for easy management -->
<div class="site-wrap js-site-wrap">

    <!-- SLIDER COMPONENT: Uses slick js -->
    <div class="widget js-widget">
        <div class="widget__content">
            <div class="banner js-banner-slider banner--slider">
                <div class="slider slider--dots">
                    <div id="main_slider" class="slider__block js-slick-slider">
                        <div class="slider__item">
                            <div class="slider__preview">
                                <div class="slider__img"><img data-lazy="<?php echo get_template_directory_uri(); ?>/img/slider/slide1.jpg" src="<?php echo get_template_directory_uri(); ?>/img/lazy-image.jpg" alt=""></div>
                            </div>
                        </div>
                        <div class="slider__item">
                            <div class="slider__preview">
                                <div class="slider__img"><img data-lazy="<?php echo get_template_directory_uri(); ?>/img/slider/slide1.jpg" src="<?php echo get_template_directory_uri(); ?>/img/lazy-image.jpg" alt=""></div>
                            </div>
                        </div>
                        <div class="slider__item">
                            <div class="slider__preview">
                                <div class="slider__img"><img data-lazy="<?php echo get_template_directory_uri(); ?>/img/slider/slide1.jpg" src="<?php echo get_template_directory_uri(); ?>/img/lazy-image.jpg" alt=""></div>
                            </div>
                        </div>
                        <div class="slider__item">
                            <div class="slider__preview">
                                <div class="slider__img"><img data-lazy="<?php echo get_template_directory_uri(); ?>/img/slider/slide1.jpg" src="<?php echo get_template_directory_uri(); ?>/img/lazy-image.jpg" alt=""></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- TWO COLUMN PANEL INTRODUCTION COMPONENT-->
    <div class="widget js-widget widget--landing widget--panel-bg widget--minimal">
        <div class="widget__content">
            <section class="about about--minimal">
                <div class="about__item about__item--0">
                    <div class="about__details about__details--0">
                        <h3 class="about__name">Intro1</h3>
                        <div class="about__intro">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae, consectetur.</p>
                        </div><a href="<?php echo get_site_url(); ?>/" class="btn--link about__more">Read more</a>
                    </div>
                </div>
                <div class="about__item about__item--1">
                    <div class="about__details about__details--1">
                        <h3 class="about__name">Intro2</h3>
                        <div class="about__intro">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, ex?</p>
                        </div><a href="<?php echo get_site_url(); ?>/" class="btn--link about__more">Read more</a>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- NEXT EVENT COUNTDOWN COMPONENT: Uses jQuery countdown -->
    <div class="widget js-widget widget--landing widget--title-big">
        <div class="widget__content">
            <section class="nextevent nextevent--counttimer">
                <div class="nextevent__item">
                    <div class="nextevent__details">
                        <h2 class="widget__title">Next Upcoming event</h2>
                        <time datetime="201" class="nextevent__date">Monday, April 30th, 2017</time>
                        <h3 class="nextevent__name"><a href="<?php echo get_site_url(); ?>/">Event title</a></h3>
                        <div class="nextevent__intro">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptas recusandae neque cumque eius modi ipsa perferendis, numquam sapiente dolor quibusdam!</p>
                        </div><a href="<?php echo get_site_url(); ?>/" class="btn--link nextevent__more">Details</a>
                    </div>
                    <div class="nextevent__preview">
                        <a href="<?php echo get_site_url(); ?>/"><img src="<?php echo get_template_directory_uri(); ?>/img/placeholders/870x480/08.jpg" alt="" class="nextevent__preview-img"></a>
                        <div id="clock" data-end-date="2017/05/30" class="countdown countdown--timer js-counttimer"></div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- LATEST EVENTS COMPONENT -->
    <div class="widget js-widget widget--landing widget--title-big widget--latest_event">
        <div class="widget__content">
            <section data-modifier="ordered" class="latest_event latest_event--ordered js-latest_event">
                <h2 class="widget__title">Latest Events</h2>
                <div data-id='2' data-href="<?php echo get_site_url(); ?>/" class="latest_event__item js-latest_event-item">
                    <div class="latest_event__info">
                        <div class="latest_event__order">01</div>
                        <div class="latest_event__details">
                            <time datetime="2016" class="latest_event__time">Sunday, 30th April, 2017</time>
                            <h3 class="latest_event__name"><a href="<?php echo get_site_url(); ?>/">Event Title</a></h3>
                        </div>
                        <div class="latest_event__sep"></div>
                        <div class="latest_event__links">
                            <a href="<?php echo get_site_url(); ?>/" class="latest_event__link-item js-latest_event-video">
                                <svg class="latest_event__link-svg">
                                    <use xlink:href="#icon-video"></use>
                                </svg>
                            </a>
                        </div><a href="<?php echo get_site_url(); ?>/" class="btn--link latest_event__more">Read more</a>
                    </div>
                 </div>
                <div data-id='2' data-href="<?php echo get_site_url(); ?>/" class="latest_event__item js-latest_event-item">
                    <div class="latest_event__info">
                        <div class="latest_event__order">02</div>
                        <div class="latest_event__details">
                            <time datetime="2016" class="latest_event__time">Friday, 14th May, 2017</time>
                            <h3 class="latest_event__name"><a href="<?php echo get_site_url(); ?>/">Event Title</a></h3>
                        </div>
                        <div class="latest_event__sep"></div>
                        <div class="latest_event__links">
                            <a href="<?php echo get_site_url(); ?>/" class="latest_event__link-item js-latest_event-video">
                                <svg class="latest_event__link-svg">
                                    <use xlink:href="#icon-video"></use>
                                </svg>
                            </a>
                        </div><a href="<?php echo get_site_url(); ?>/" class="btn--link latest_event__more">Read more</a>
                    </div>
                    
                </div>
                <div data-id='2' data-href="<?php echo get_site_url(); ?>/" class="latest_event__item js-latest_event-item">
                    <div class="latest_event__info">
                        <div class="latest_event__order">03</div>
                        <div class="latest_event__details">
                            <time datetime="2016" class="latest_event__time">Sunday, 4th June, 2017</time>
                            <h3 class="latest_event__name"><a href="<?php echo get_site_url(); ?>/">Event Title</a></h3>
                        </div>
                        <div class="latest_event__sep"></div>
                        <div class="latest_event__links">
                            <a href="<?php echo get_site_url(); ?>/" class="latest_event__link-item js-latest_event-video">
                                <svg class="latest_event__link-svg">
                                    <use xlink:href="#icon-video"></use>
                                </svg>
                            </a>
                        </div><a href="<?php echo get_site_url(); ?>/" class="btn--link latest_event__more">Read more</a>
                    </div>
                    
                </div>
                <!-- END latest_event ORDERED ITEM-->
            </section>
            <!-- END latest_event ORDERED-->
        </div>
    </div>

    <!-- TWO-COLUMN FEATURE COMPONENT: Image on left side -->
    <div class="widget js-widget">
        <div class="widget__content">
            <section class="feature">
                <div class="feature__picture_left"></div>
                <div class="container">
                    <div class="feature__content_right">
                        <div class="feature__header">
                            <h3 data-sr="enter right ease-in-out 150px" class="feature__title">big title</h3>
                            <h4 data-sr="enter right ease-in-out 250px" class="feature__headline">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit sapiente minima quod, excepturi? Doloribus
                                minus nemo harum voluptates, vero. Ex velit esse eius aperiam consectetur, eaque ullam pariatur dicta,
                                blanditiis in expedita ipsum ipsa magnam, minima necessitatibus incidunt temporibus, vitae!</h4>
                        </div>
                        <div class="feature__list">
                            <div data-sr="enter right ease 150px" class="feature__item">
                                <svg class="feature__icon feature__icon--money-save">
                                    <use xlink:href="#icon-geolocation"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse et aliquid aut necessitatibus qui
                                            tempore dolor tenetur repellat quisquam quasi.</p>
                                    </div>
                                </div>
                            </div>
                            <div data-sr="enter right ease 250px" class="feature__item">
                                <svg class="feature__icon feature__icon--good-sales">
                                    <use xlink:href="#icon-customers"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit incidunt culpa ad nesciunt. Odio nostrum
                                            repellat quaerat aut eaque, officiis.</p>
                                    </div>
                                </div>
                            </div>
                            <div data-sr="enter right ease 150px" class="feature__item">
                                <svg class="feature__icon">
                                    <use xlink:href="#icon-comfort"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, ex.</p>
                                    </div>
                                </div>
                            </div>
                            <div data-sr="enter right ease 250px" class="feature__item">
                                <svg class="feature__icon">
                                    <use xlink:href="#icon-easy"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor autem similique vitae impedit placeat
                                            mollitia.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- TWO-COLUMN FEATURE COMPONENT: Image on right side -->
    <div class="widget js-widget">
        <div class="widget__content">
            <section class="feature">
                <div class="feature__picture_right"></div>
                <div class="container">
                    <div class="feature__content_left">
                        <div class="feature__header">
                            <h3 data-sr="enter left ease-in-out 150px" class="feature__title">Big title</h3>
                            <h4 data-sr="enter left ease-in-out 250px" class="feature__headline">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit sapiente minima quod, excepturi? Doloribus
                                minus nemo harum voluptates, vero. Ex velit esse eius aperiam consectetur, eaque ullam pariatur dicta,
                                blanditiis in expedita ipsum ipsa magnam, minima necessitatibus incidunt temporibus, vitae!</h4>
                        </div>
                        <div class="feature__list">
                            <div data-sr="enter left ease 150px" class="feature__item">
                                <svg class="feature__icon feature__icon--money-save">
                                    <use xlink:href="#icon-doc"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse et aliquid aut necessitatibus qui
                                            tempore dolor tenetur repellat quisquam quasi.</p>
                                    </div>
                                </div>
                            </div>
                            <div data-sr="enter left ease 250px" class="feature__item">
                                <svg class="feature__icon feature__icon--good-sales">
                                    <use xlink:href="#icon-good-sales"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit incidunt culpa ad nesciunt. Odio nostrum
                                            repellat quaerat aut eaque, officiis.</p>
                                    </div>
                                </div>
                            </div>
                            <div data-sr="enter left ease 150px" class="feature__item">
                                <svg class="feature__icon">
                                    <use xlink:href="#icon-clock"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas, ex.</p>
                                    </div>
                                </div>
                            </div>
                            <div data-sr="enter left ease 250px" class="feature__item">
                                <svg class="feature__icon">
                                    <use xlink:href="#icon-blog-edit"></use>
                                </svg>
                                <div class="feature__item-content">
                                    <h3 class="feature__item-title">Normal title</h3>
                                    <div class="feature__text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor autem similique vitae impedit placeat
                                            mollitia.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <!-- ORGANISATION MEMBERS COMPONENT -->
    <div class="widget js-widget widget--landing widget--gray">
        <div class="widget__header">
            <h2 class="widget__title">Our Members</h2>
            <h5 class="widget__headline">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium quaerat iure expedita. Quis saepe nemo modi,
                voluptas impedit similique cumque? Est dolorem officiis libero reprehenderit voluptate repellendus nobis animi
                dicta? Omnis, nemo, architecto. Pariatur, qui. Sed eum deserunt nesciunt eaque.</h5>
        </div>
        <div class="widget__content">
            <div class="listing listing--grid listing--lg-4">
                <div class="listing__item">
                    <div data-sr="enter bottom move 80px, scale(0), over 0s" data-animate-end="animate-end" class="member js-unhide-block vcard member--index">
                        <div class="member__photo">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo item-photo--static"><img src="<?php echo get_template_directory_uri(); ?>/img/members/member-1.jpg" alt="Name" class="photo" /></a>
                            <div class="member__details"><span class="member__post">Lorem ipsum dolor.</span>
                                <div class="member__links">
                                    <a class="member__link">
                                        <svg class="member__link-icon">
                                            <use xlink:href="#icon-mail"></use>
                                        </svg>
                                    </a><a class="member__link"><i class="fa fa-linkedin"></i></a><a class="member__link"><i class="fa fa-facebook"></i></a>
                                    <a
                                        class="member__link"><i class="fa fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="member__info">
                            <h4 class="member__name fn">Name</h4><a href="<?php echo get_site_url(); ?>/" class="member__more">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div data-sr="enter bottom move 80px, scale(0), over 0s" data-animate-end="animate-end" class="member js-unhide-block vcard member--index">
                        <div class="member__photo">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo item-photo--static"><img src="<?php echo get_template_directory_uri(); ?>/img/members/member-2.jpg" alt="Name" class="photo" /></a>
                            <div class="member__details"><span class="member__post">Lorem ipsum dolor.</span>
                                <div class="member__links">
                                    <a class="member__link">
                                        <svg class="member__link-icon">
                                            <use xlink:href="#icon-mail"></use>
                                        </svg>
                                    </a><a class="member__link"><i class="fa fa-linkedin"></i></a><a class="member__link"><i class="fa fa-facebook"></i></a>
                                    <a
                                        class="member__link"><i class="fa fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="member__info">
                            <h4 class="member__name fn">Name</h4><a href="<?php echo get_site_url(); ?>/" class="member__more">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div data-sr="enter bottom move 80px, scale(0), over 0s" data-animate-end="animate-end" class="member js-unhide-block vcard member--index">
                        <div class="member__photo">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo item-photo--static"><img src="<?php echo get_template_directory_uri(); ?>/img/members/member-3.jpg" alt="Name" class="photo" /></a>
                            <div class="member__details"><span class="member__post">Lorem ipsum dolor.</span>
                                <div class="member__links">
                                    <a class="member__link">
                                        <svg class="member__link-icon">
                                            <use xlink:href="#icon-mail"></use>
                                        </svg>
                                    </a><a class="member__link"><i class="fa fa-linkedin"></i></a><a class="member__link"><i class="fa fa-facebook"></i></a>
                                    <a
                                        class="member__link"><i class="fa fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="member__info">
                            <h4 class="member__name fn">Name</h4><a href="<?php echo get_site_url(); ?>/" class="member__more">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div data-sr="enter bottom move 80px, scale(0), over 0s" data-animate-end="animate-end" class="member js-unhide-block vcard member--index">
                        <div class="member__photo">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo item-photo--static"><img src="<?php echo get_template_directory_uri(); ?>/img/members/member-4.jpg" alt="Name" class="photo" /></a>
                            <div class="member__details"><span class="member__post">Lorem ipsum dolor.</span>
                                <div class="member__links">
                                    <a class="member__link">
                                        <svg class="member__link-icon">
                                            <use xlink:href="#icon-mail"></use>
                                        </svg>
                                    </a><a class="member__link"><i class="fa fa-linkedin"></i></a><a class="member__link"><i class="fa fa-facebook"></i></a>
                                    <a
                                        class="member__link"><i class="fa fa-twitter"></i></a>
                                </div>
                            </div>
                        </div>
                        <div class="member__info">
                            <h4 class="member__name fn">Name</h4><a href="<?php echo get_site_url(); ?>/" class="member__more">Read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ORGANISATION PROJECT COMPONENT -->
    <div class="widget js-widget widget--landing">
        <div class="widget__header">
            <h2 class="widget__title"><span class="title-thin">Our</span> Projects</h2>
            <h5 class="widget__headline">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis assumenda ullam, ea deleniti inventore commodi quidem
                cum animi delectus doloribus debitis impedit, vel eum ipsam libero atque, vero molestiae tempore nihil a labore
                ducimus eaque. Dignissimos amet a, sed, alias repellat molestiae labore illum aspernatur, eum nihil deserunt!
                Voluptates, magnam.</h5>
        </div>
        <div class="widget__content">
            <div class="listing listing--grid">
                <div class="listing__item">
                    <div class="projects projects--grid projects--projects">
                        <div class="projects__thumb">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo"><img src="<?php echo get_template_directory_uri(); ?>/img/placeholders/554x360/06.jpg" alt="" />
                                <figure class="item-photo__hover item-photo__hover--params"><span class="projects__intro">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad, rerum...</span>
                                    <span
                                        class="projects__time">Completed: 3 years ago</span><span class="projects__more">View details</span>
                                </figure>
                            </a><span class="projects__ribon">complete</span>
                        </div>
                        <div class="projects__details">
                            <div class="projects__info"><a href="<?php echo get_site_url(); ?>/" class="projects__address"><span class="projects__address-street">Project Title</span><span class="projects__address-city">Category</span></a>
                                <div class="projects__params--mob"><a href="<?php echo get_site_url(); ?>/" class="projects__more">View details</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div class="projects projects--grid projects--projects">
                        <div class="projects__thumb">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo"><img src="<?php echo get_template_directory_uri(); ?>/img/placeholders/554x360/07.jpg" alt="" />
                                <figure class="item-photo__hover item-photo__hover--params"><span class="projects__intro">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae, ad...</span>
                                    <span
                                        class="projects__time">Started: 15 days ago</span><span class="projects__more">View details</span>
                                </figure>
                            </a><span class="projects__ribon">pending</span>
                        </div>
                        <div class="projects__details">
                            <div class="projects__info"><a href="<?php echo get_site_url(); ?>/" class="projects__address"><span class="projects__address-street">Project Title</span><span class="projects__address-city">Category</span></a>
                                <div class="projects__params--mob"><a href="<?php echo get_site_url(); ?>/" class="projects__more">View details</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div class="projects projects--grid projects--projects">
                        <div class="projects__thumb">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo"><img src="<?php echo get_template_directory_uri(); ?>/img/placeholders/554x360/08.jpg" alt="" />
                                <figure class="item-photo__hover item-photo__hover--params"><span class="projects__intro">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Illo dolor, reprehenderit quia aliquam veniam porro...</span>
                                    <span
                                        class="projects__time">Completed: 6 months ago</span><span class="projects__more">View details</span>
                                </figure>
                            </a><span class="projects__ribon">complete</span>
                        </div>
                        <div class="projects__details">
                            <div class="projects__info"><a href="<?php echo get_site_url(); ?>/" class="projects__address"><span class="projects__address-street">Project Title</span><span class="projects__address-city">Category</span></a>
                                <div class="projects__params--mob"><a href="<?php echo get_site_url(); ?>/" class="projects__more">View details</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div class="projects projects--grid projects--projects">
                        <div class="projects__thumb">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo"><img src="<?php echo get_template_directory_uri(); ?>/img/placeholders/554x360/09.jpg" alt="" />
                                <figure class="item-photo__hover item-photo__hover--params"><span class="projects__intro">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero nobis dolorum deleniti quam ab aliquam quasi velit eligendi alias, quia repellat quo, doloribus nam, animi...</span>
                                    <span
                                        class="projects__time">To begin: Next year</span><span class="projects__more">View details</span>
                                </figure>
                            </a><span class="projects__ribon">future</span>
                        </div>
                        <div class="projects__details">
                            <div class="projects__info"><a href="<?php echo get_site_url(); ?>/" class="projects__address"><span class="projects__address-street">Project Title</span><span class="projects__address-city">Category</span></a>
                                <div class="projects__params--mob"><a href="<?php echo get_site_url(); ?>/" class="projects__more">View details</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div class="projects projects--grid projects--projects">
                        <div class="projects__thumb">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo"><img src="<?php echo get_template_directory_uri(); ?>/img/placeholders/554x360/10.jpg" alt="" />
                                <figure class="item-photo__hover item-photo__hover--params"><span class="projects__intro">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero eos nostrum tempore facere voluptates excepturi harum assumenda laudantium? Ipsum, corporis</span>
                                    <span
                                        class="projects__time">Started: 2 weeks ago</span><span class="projects__more">View details</span>
                                </figure>
                            </a><span class="projects__ribon">pending</span>
                        </div>
                        <div class="projects__details">
                            <div class="projects__info"><a href="<?php echo get_site_url(); ?>/" class="projects__address"><span class="projects__address-street">Project Title</span><span class="projects__address-city">Category</span></a>
                                <div class="projects__params--mob"><a href="<?php echo get_site_url(); ?>/" class="projects__more">View details</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div class="projects projects--grid projects--projects">
                        <div class="projects__thumb">
                            <a href="<?php echo get_site_url(); ?>/" class="item-photo"><img src="<?php echo get_template_directory_uri(); ?>/img/placeholders/554x360/11.jpg" alt="" />
                                <figure class="item-photo__hover item-photo__hover--params"><span class="projects__intro">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo doloribus, culpa? Ipsa, quas perferendis, impedit accusantium, officiis non quos rerum corporis sed delectus, iusto debitis...</span>
                                    <span
                                        class="projects__time">Started: 1 week ago</span><span class="projects__more">View details</span>
                                </figure>
                            </a><span class="projects__ribon">ongoing</span>
                        </div>
                        <div class="projects__details">
                            <div class="projects__info"><a href="<?php echo get_site_url(); ?>/" class="projects__address"><span class="projects__address-street">Project Title</span><span class="projects__address-city">Category</span></a>
                                <div class="projects__params--mob"><a href="<?php echo get_site_url(); ?>/" class="projects__more">View details</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="widget__footer"><a href="<?php echo get_site_url(); ?>/" class="widget__more">More projects</a></div>
        </div>
    </div>

    <!-- FEATURED NEWS/BLOG ARTICLES COMPONENT -->
    <div class="widget js-widget widget--landing widget--gray">
        <div class="widget__header">
            <h2 class="widget__title">News & Blog</h2>
            <h5 class="widget__headline">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis, explicabo.</h5>
        </div>
        <div class="widget__content">
            <div class="listing listing--grid">
                <div class="listing__item">
                    <div class="article article--grid">
                        <a href="<?php echo get_site_url(); ?>/" class="article__photo"><img src="<?php echo get_template_directory_uri(); ?>/img/news/news-1.jpg" alt="News title" class="article__photo-img">
                            <time datetime="2017-04-20" class="article__time">APR<strong>20</strong></time>
                        </a>
                        <div class="article__details"><a href="<?php echo get_site_url(); ?>/" class="article__item-title">News Title</a>
                            <div class="article__intro">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, repellendus! ...</p>
                            </div><a href="<?php echo get_site_url(); ?>/" class="article__more">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div class="article article--grid">
                        <a href="<?php echo get_site_url(); ?>/" class="article__photo"><img src="<?php echo get_template_directory_uri(); ?>/img/news/news-2.jpg" alt="News title" class="article__photo-img">
                            <time datetime="2017-04-20" class="article__time">MAR<strong>18</strong></time>
                        </a>
                        <div class="article__details"><a href="<?php echo get_site_url(); ?>/" class="article__item-title">News Title</a>
                            <div class="article__intro">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione, repellendus! ...</p>
                            </div><a href="<?php echo get_site_url(); ?>/" class="article__more">Read more</a>
                        </div>
                    </div>
                </div>
                <div class="listing__item">
                    <div class="article article--grid">
                        <a href="<?php echo get_site_url(); ?>/" class="article__photo"><img src="<?php echo get_template_directory_uri(); ?>/img/news/news-3.jpg" alt="News title" class="article__photo-img">
                            <time datetime="2017-04-20" class="article__time">FEB<strong>04</strong></time>
                        </a>
                        <div class="article__details"><a href="<?php echo get_site_url(); ?>/" class="article__item-title">News Title</a>
                            <div class="article__intro">
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, velit? ...</p>
                            </div><a href="<?php echo get_site_url(); ?>/" class="article__more">Read more</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="widget__footer"><a href="<?php echo get_site_url(); ?>/" class="widget__more"> More articles...</a></div>
        </div>
    </div>

    <!-- TESTIMONIALS SLIDE COMPONENT -->
    <div class="widget js-widget widget--landing">
        <div class="widget__header">
            <h2 class="widget__title">Testimonials</h2>
            <h5 class="widget__headline">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur iure, repellendus dolorem sit dolorum libero.</h5>
        </div>
        <div class="widget__content">
            <div id="review-slider" class="review review--wide">
                <div id="testimonial_slider" class="review__slider js-slick-slider">
                    <div class="review__item">
                        <div class="review__photo"><img src="<?php echo get_template_directory_uri(); ?>/img/testimonials/01.jpg" alt="ALT" class="review__photo-img"></div>
                        <div class="review__details"><span class="review__name">Person 1</span><span class="review__post">Lorem ipsum.</span>
                            <div class="review__stars"><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i>
                                <i
                                    class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i></div>
                        </div>
                        <div class="review__info">
                            <div class="review__info-quote review__info-quote--open">&rdquo;</div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat commodi aliquam minus, nostrum error
                                unde dolore nam facere quod. Consectetur.
                            </p>
                            <div class="review__info-quote review__info-quote--close">&ldquo;</div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="review__item">
                        <div class="review__photo"><img src="<?php echo get_template_directory_uri(); ?>/img/testimonials/02.jpg" alt="ALT" class="review__photo-img"></div>
                        <div class="review__details"><span class="review__name">Person 2</span><span class="review__post">Lorem ipsum.</span>
                            <div class="review__stars"><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i>
                                <i
                                    class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i></div>
                        </div>
                        <div class="review__info">
                            <div class="review__info-quote review__info-quote--open">&rdquo;</div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat commodi aliquam minus, nostrum error
                                unde dolore nam facere quod. Consectetur.
                            </p>
                            <div class="review__info-quote review__info-quote--close">&ldquo;</div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="review__item">
                        <div class="review__photo"><img src="<?php echo get_template_directory_uri(); ?>/img/testimonials/03.jpg" alt="ALT" class="review__photo-img"></div>
                        <div class="review__details"><span class="review__name">Person 3</span><span class="review__post">Lorem ipsum.</span>
                            <div class="review__stars"><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i>
                                <i
                                    class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i></div>
                        </div>
                        <div class="review__info">
                            <div class="review__info-quote review__info-quote--open">&rdquo;</div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat commodi aliquam minus, nostrum error
                                unde dolore nam facere quod. Consectetur.
                            </p>
                            <div class="review__info-quote review__info-quote--close">&ldquo;</div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="review__item">
                        <div class="review__photo"><img src="<?php echo get_template_directory_uri(); ?>/img/testimonials/04.jpg" alt="ALT" class="review__photo-img"></div>
                        <div class="review__details"><span class="review__name">Person 4</span><span class="review__post">Lorem ipsum.</span>
                            <div class="review__stars"><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i>
                                <i
                                    class="glyphicon glyphicon-star"></i><i class="glyphicon glyphicon-star"></i></div>
                        </div>
                        <div class="review__info">
                            <div class="review__info-quote review__info-quote--open">&rdquo;</div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat commodi aliquam minus, nostrum error
                                unde dolore nam facere quod. Consectetur.
                            </p>
                            <div class="review__info-quote review__info-quote--close">&ldquo;</div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Define center section to separate upper and lower sections -->
    <div class="center">
        <div class="container">
        </div>
    </div>

    <!-- ORGANIZATION PARTNERS SLIDE COMPONENT -->
    <div class="widget js-widget widget--landing widget--gray">
        <div class="widget__header">
            <h2 class="widget__title"><span class="title-thin">Our</span> Partners</h2>
            <h5 class="widget__headline">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Veritatis labore a consectetur laboriosam voluptatibus
                eaque, mollitia voluptate quod temporibus assumenda.</h5>
        </div>
        <div class="widget__content">
            <div id="partners-slider" class="partners">
                <div id="partners_slider" class="partners__slider js-slick-slider">
                    <a class="partners__item"><img src="<?php echo get_template_directory_uri(); ?>/img/partners/logo-company-1.png" alt=""><span class="partners__name">Partner 1</span></a>
                    <a
                        class="partners__item"><img src="<?php echo get_template_directory_uri(); ?>/img/partners/logo-company-2.png" alt=""><span class="partners__name">Partner 2</span></a>
                    <a
                        class="partners__item"><img src="<?php echo get_template_directory_uri(); ?>/img/partners/logo-company-3.png" alt=""><span class="partners__name">Partner 3</span></a>
                    <a
                        class="partners__item"><img src="<?php echo get_template_directory_uri(); ?>/img/partners/logo-company-4.png" alt=""><span class="partners__name">Partner 4</span></a>
                    <a
                        class="partners__item"><img src="<?php echo get_template_directory_uri(); ?>/img/partners/logo-company-5.png" alt=""><span class="partners__name">Partner 5</span></a>
                    <a
                        class="partners__item"><img src="<?php echo get_template_directory_uri(); ?>/img/partners/logo-company-3.png" alt=""><span class="partners__name">Partner 6</span></a>
                    <a
                        class="partners__item"><img src="<?php echo get_template_directory_uri(); ?>/img/partners/logo-company-2.png" alt=""><span class="partners__name">Partner 7</span></a>
                </div>
                <div class="partners__controls">
                    <button class="partners__arrow partners__arrow--prev js-partners-prev"></button>
                    <button class="partners__arrow partners__arrow--next js-partners-next"></button>
                </div>
            </div>
        </div>
    </div>

<?php get_footer(); ?>
