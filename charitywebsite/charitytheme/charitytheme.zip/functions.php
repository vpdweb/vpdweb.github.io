<?php

// Enqueue scripts and stylesheets

// Scripts
function charitywebwp_scripts()
{
    wp_deregister_script('jquery');

    wp_enqueue_script('jquery', '//ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js', array(), null, true);

//    wp_enqueue_script('bootstrapjs', '//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array('jquery'), null, true);

    wp_enqueue_script('scrolltriggerjs', get_template_directory_uri() . '/js/ScrollTrigger.min.js', array(), null, true);

    wp_enqueue_script('slickjs', '//cdn.jsdelivr.net/jquery.slick/1.6.0/slick.min.js', array('jquery'), null, true);

    wp_enqueue_script('countdownjs', get_template_directory_uri() . '/js/jquery.countdown.min.js', array('jquery'), null, true);

    wp_enqueue_script('appjs', get_template_directory_uri() . '/js/app.js', array('slickjs', 'countdownjs', 'scrolltriggerjs'), null, true);

}

// Styles
function charitywebwp_styles()
{
   wp_register_style('thirdpartycss', get_template_directory_uri() . '/css/thirdparty.css', array(), null, 'all');
    wp_enqueue_style('thirdpartycss'); // Enqueue it!

    wp_register_style('fontawesome', get_template_directory_uri() . '/css/font-awesome.css', array(), null, 'all');
    wp_enqueue_style('fontawesome'); // Enqueue it!

    wp_register_style('maincss', get_template_directory_uri() . '/style.css', array(), null, 'all');
    wp_enqueue_style('maincss'); // Enqueue it!
    
}

// Load actions
add_action('wp_enqueue_scripts', 'charitywebwp_scripts');
add_action('wp_enqueue_scripts', 'charitywebwp_styles');

// Pagination for paged posts, Page 1, Page 2, Page 3, with Next and Previous Links, No plugin
function charitywebwp_pagination()
{
    global $wp_query;
    $big = 999999999;
    echo paginate_links(array(
        'base' => str_replace($big, '%#%', get_pagenum_link($big)),
        'format' => '?paged=%#%',
        'current' => max(1, get_query_var('paged')),
        'total' => $wp_query->max_num_pages
    ));
}

// Custom Excerpts
function charitywebwp_index($length) // Create 20 Word Callback for Index page Excerpts, call using charitywebwp_excerpt('charitywebwp_index');
{
    return 20;
}

// Create 40 Word Callback for Custom Post Excerpts, call using charitywebwp_excerpt('charitywebwp_custom_post');
function charitywebwp_custom_post($length)
{
    return 40;
}

// Create a Custom Excerpts callback
function charitywebwp_excerpt($length_callback = '', $more_callback = '')
{
global $post;
if (function_exists($length_callback)) {
add_filter('excerpt_length', $length_callback);
}
if (function_exists($more_callback)) {
add_filter('excerpt_more', $more_callback);
}
$output = get_the_excerpt();
$output = apply_filters('wptexturize', $output);
$output = apply_filters('convert_chars', $output);
$output = '<p>' . $output . '</p>';
echo $output;
}

// For the main menu section
function register_my_menu() {
    register_nav_menu('main-menu',__( 'Main Menu' ));
}
add_action( 'init', 'register_my_menu' );


?>