<!-- pagination -->
<div class="pagination">
    <?php charitywebwp_pagination(); ?>
</div>
<!-- /pagination -->