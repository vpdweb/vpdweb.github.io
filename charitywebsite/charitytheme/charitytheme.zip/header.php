<!DOCTYPE html>
<html>

<head lang="en">
    <meta charset="UTF-8">
    <title><?php bloginfo('title'); ?></title>
    <!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=9,chrome=1"><![endif]-->

    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0, shrink-to-fit=no">

    <!-- Main font from Google Fonts: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7cSource+Sans+Pro:200,400,600,700,900,400italic,700italic&amp;subset=latin,latin-ext" rel="stylesheet" type="text/css">

    <!-- Fixes for IE-->
    <!--[if lt IE 11]>
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie-fix.css">
    <![endif]-->

    <!-- Site favicon -->
    <link rel="icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.ico" type="image/x-icon">

    <?php wp_head(); ?>
</head>

<body class="index_slider_search menu-default hover-default slider--fadeInLeft ">

<!-- SVG ICON DEFINIITONS. DO NOT REMOVE. -->
<svg width="0" height="0" style="position:absolute">
    <symbol viewBox="0 0 264 88" id="default-skin">
        <g fill="none" fill-rule="evenodd">
            <path d="M67.002 59.5v3.768c-6.307.84-9.184 5.75-10.002 9.732 2.22-2.83 5.564-5.098 10.002-5.098V71.5L73 65.585 67.002 59.5zM13 29v-5h2v3h3v2h-5zm0-14h5v2h-3v3h-2v-5zm18 0v5h-2v-3h-3v-2h5zm0 14h-5v-2h3v-3h2v5zm31-5v5h-2v-3h-3v-2h5zm0-4h-5v-2h3v-3h2v5zm8 0v-5h2v3h3v2h-5zm0 4h5v2h-3v3h-2v-5zM20.586 66l-5.656-5.656 1.414-1.414L22 64.586l5.656-5.656 1.414 1.414L23.414 66l5.656 5.656-1.414 1.414L22 67.414l-5.656 5.656-1.414-1.414L20.586 66zm91.199-.97L110 63.5l3-3.5h-10v-2h10l-3-3.5 1.785-1.468L117 59l-5.215 6.03zm40.43 0L154 63.5l-3-3.5h10v-2h-10l3-3.5-1.785-1.468L147 59l5.215 6.03zm8.742-36.487l-3.25-3.25-1.413 1.414 3.25 3.25z"
                  fill="#fff" />
            <path d="M152.5 27a5.5 5.5 0 1 0 0-11 5.5 5.5 0 1 0 0 11z" stroke="#fff" stroke-width="1.5" />
            <path fill="#fff" d="M150 21h5v1h-5zM116.957 28.543l-1.414 1.414-3.25-3.25 1.414-1.414 3.25 3.25z" />
            <path d="M108.5 27a5.5 5.5 0 1 0 0-11 5.5 5.5 0 1 0 0 11z" stroke="#fff" stroke-width="1.5" />
            <path fill="#fff" d="M106 21h5v1h-5z" />
            <path fill="#fff" d="M109.043 19.008l-.085 5-1-.017.085-5z" />
        </g>
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-add--favorites">
        <path d="M15.7 9.2l.5-.5-4.2-.6-1.9-3.8-1.8 3.8-4.2.6 3 3-.7 4.2 3.8-2 1.7.9c.6.8 1.6 1.3 2.7 1.3 1.9 0 3.5-1.6 3.5-3.5C18 11 17 9.7 15.7 9.2zM11 12.5c0 .2 0 .5.1.7l-.9-.5L7.7 14l.5-2.7-2-1.9L8.9 9l1.2-2.5L11.3 9l1.8.3c-1.2.5-2.1 1.7-2.1 3.2zm3.5 2.5c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.2 2.5-2.5 2.5zm.5-4h-1v1h-1v1h1v1h1v-1h1v-1h-1v-1z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-add--gallery">
        <path d="M17.5 8c-.5 0-1.5.1-1.5.3V5H2v11h14v-1.3c0 .2 1 .3 1.5.3 1.9 0 3.5-1.6 3.5-3.5S19.4 8 17.5 8zM3 6h12v3c-1 .6-1 1.5-1 2.5 0 .5.2 1 .4 1.5h-.1L12 10.2l-1.9 2-3.1-4-4 4.5V6zm12 9H3v-1h.2l3.7-4.2 3 4.1 2-2.1 1.9 2.2H15v1zm2.5-1c-1.4 0-2.5-1.1-2.5-2.5S16.1 9 17.5 9s2.5 1.1 2.5 2.5-1.1 2.5-2.5 2.5zm.5-4h-1v1h-1v1h1v1h1v-1h1v-1h-1v-1z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-add--post">
        <path d="M12 8H5v1h7V8zm0 2H5v1h7v-1zm-7 3h4v-1H5v1zm10.5-3c-.5 0-1 .1-1.5.3V4H3v14h11v-1.3c.4.2.9.3 1.5.3 1.9 0 3.5-1.6 3.5-3.5S17.4 10 15.5 10zM13 17H4V5h9v6c-.6.6-1 1.5-1 2.5s.4 1.9 1 2.5v1zm2.5-1c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.2 2.5-2.5 2.5zm.5-4h-1v1h-1v1h1v1h1v-1h1v-1h-1v-1z"
        />
    </symbol>
    <symbol viewBox="0 0 20 20" id="icon-arrow-end">
        <path clip-rule="evenodd" fill="none" d="M.4 5.9l15.8-4.5 1.6 1.2 1.1 17" />
    </symbol>
    <symbol preserveAspectRatio="xMidYMid" viewBox="0 0 21 40" id="icon-arrow-left">
        <path d="M20-.001L0 19.998l20 20.001" />
    </symbol>
    <symbol preserveAspectRatio="xMidYMid" viewBox="0 0 21 40" id="icon-arrow-right">
        <path d="M1-.001l20 19.999L1 39.999" />
    </symbol>
    <symbol viewBox="0 0 186 186" id="icon-avatar">
        <path d="M161.1 140.4c-26.5-6.1-51.2-11.5-39.3-34.1C158.2 37.6 131.4.8 93 .8 53.8.8 27.7 39 64.2 106.3c12.3 22.7-13.3 28.1-39.3 34.1C-1.6 146.6.4 160.6.4 186h185.1c.1-25.4 2.1-39.4-24.4-45.6z"
        />
    </symbol>
    <symbol viewBox="0 0 30 30" id="icon-blog-edit">
        <path d="M8 10h7v2H8zm0 4h7v2H8zm0 4h4v2H8zm11 3h-4v-4l7.94-8.07 4.21 4.12zm-2-2h1.18l6.11-6L23 11.75l-6 6.07V19z" />
        <path d="M18.59 20H18v2H6V7h12v8.38l2-2.04V5H4v19h16v-5.38L18.59 20z" />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-captions-off">
        <path d="M1 2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H1zm1 12V4h14v10H2z" />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-captions-on">
        <path d="M1 2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H1zm1 12V4h14v10H2z" />
        <path d="M3 11h3v2H3zm9 0h3v2h-3zm-5 0h4v2H7z" />
    </symbol>
    <symbol viewBox="0 0 30 30" id="icon-chat">
        <path d="M23 23.08L16.65 18H7v-7h9.65L23 5.84v17.24zM9 16h8.35L21 18.92V10l-3.65 3H9v3z" />
        <circle cx="23" cy="14.47" r="2" />
        <path d="M12 17h3v7h-3z" />
    </symbol>
    <symbol viewBox="0 0 30 30" id="icon-clock">
        <path d="M14.83 23.83a9 9 0 1 1 9-9 9 9 0 0 1-9 9zm0-16a7 7 0 1 0 7 7 7 7 0 0 0-7-7z" />
        <path d="M13.95 9.83h2v5.13h-2z" />
        <path d="M13.94 13.95h3.96v2h-3.96z" />
    </symbol>
    <symbol viewBox="-618.5 373.5 55 55" id="icon-comfort">
        <path d="M-591 388.5c-6.6 0-12 5.4-12 12s5.4 12 12 12 12-5.4 12-12-5.4-12-12-12zm0 22c-5.5 0-10-4.5-10-10s4.5-10 10-10 10 4.5 10 10-4.5 10-10 10zm11.7-20.2c.3 0 .5-.1.7-.3l4.6-4.6c.4-.4.4-1 0-1.4s-1-.4-1.4 0l-4.6 4.6c-.4.4-.4 1 0 1.4.2.2.4.3.7.3zm11.3 9.7h-6.5c-.6 0-1 .4-1 1s.4 1 1 1h6.5c.6 0 1-.4 1-1s-.4-1-1-1zm-10.6 12c-.4-.4-1-.4-1.4 0s-.4 1 0 1.4l4.6 4.6c.2.2.5.3.7.3s.5-.1.7-.3c.4-.4.4-1 0-1.4l-4.6-4.6zm-12.4 4.5c-.6 0-1 .4-1 1v6.5c0 .6.4 1 1 1s1-.4 1-1v-6.5c0-.5-.4-1-1-1zm-12.4-4.5l-4.6 4.6c-.4.4-.4 1 0 1.4.2.2.5.3.7.3s.5-.1.7-.3l4.6-4.6c.4-.4.4-1 0-1.4s-1-.4-1.4 0zm-3.1-11c0-.6-.4-1-1-1h-6.5c-.6 0-1 .4-1 1s.4 1 1 1h6.5c.5 0 1-.4 1-1zm3.1-11c.2.2.5.3.7.3s.5-.1.7-.3c.4-.4.4-1 0-1.4l-4.6-4.6c-.3-.4-1-.4-1.4 0s-.4 1 0 1.4l4.6 4.6zm12.4-4.5c.6 0 1-.4 1-1V378c0-.6-.4-1-1-1s-1 .4-1 1v6.5c0 .5.4 1 1 1z"
        />
    </symbol>
    <symbol viewBox="0 0 40 40" id="icon-customers">
        <path d="M32.7 24l-.1.8s-.3 1.7-3.2 1.7c-2.8 0-3.2-1.5-3.2-1.7l-.3-.8H23v-5h-6.3l-.2.7c0 .1-.8 2.7-4.4 2.7s-4.3-2.6-4.3-2.7l-.1-.7H2v20h36V24h-5.3zM21 37H4V21h2.2c.7 1 2.5 3.4 6 3.4s5.3-2.4 6-3.4H21v16zm15 0H23V26h1.4c.6 1 2 2.5 4.9 2.5 2.9 0 4.3-1.5 4.9-2.5H36v11zm-6.7-14.8c3.3 0 6-2.7 6-6s-2.7-6-6-6-6 2.7-6 6 2.7 6 6 6zm0-10c2.2 0 4 1.8 4 4s-1.8 4-4 4-4-1.8-4-4 1.8-4 4-4zM12.2 17c4.4 0 8-3.6 8-8s-3.6-8-8-8-8 3.6-8 8 3.6 8 8 8zm0-14c3.3 0 6 2.7 6 6s-2.7 6-6 6-6-2.7-6-6 2.7-6 6-6z"
        />
    </symbol>
    <symbol viewBox="0 0 28 35" id="icon-doc">
        <path d="M7 25h14v-2H7v2zm0-5h14v-2H7v2zm0-5h14v-2H7v2zm21-5.8v-.9L19.9 0H2.5C1.1 0 0 1.2 0 2.6v29.8C0 33.8 1.1 35 2.5 35h22.9c1.4 0 2.5-1.2 2.5-2.6V9.2h.1zm-2 23.2c0 .3-.2.6-.5.6h-23c-.3 0-.5-.3-.5-.6V2.6c0-.3.2-.6.5-.6H19v7.2h7v23.2z"
        />
    </symbol>
    <symbol viewBox="0 0 14 14" id="icon-earth">
        <path d="M12.5 7c0-3-2.5-5.5-5.5-5.5-2.8 0-5.1 2.1-5.4 4.7v1c.1 2.9 2.4 5.2 5.3 5.3h.6c2.8-.2 5-2.6 5-5.5zM7.1 2.7C7.7 3.1 8.6 4 8.8 6H5.4c.3-2 1.2-2.9 1.7-3.3zM8.9 7c0 3-1.1 3.9-1.7 4.4v-.1C6.5 10.8 5.4 10 5.4 7h3.5zm-.1 3.9C9.4 10 9.9 9 9.9 7h1.6c-.1 2-1.2 3.2-2.7 3.9zM11.4 6H9.8C9.6 5 9 3.2 8.4 2.5c1.5.5 2.7 2.5 3 3.5zM6 2.4C5.3 3.1 4.6 4 4.4 6H2.6C2.9 4 4.2 2.8 6 2.4zM2.5 7h1.9c0 2 .5 3.1 1.1 4-1.7-.6-2.9-2-3-4z"
        />
    </symbol>
    <symbol viewBox="-632.3 373.3 55 55" id="icon-easy">
        <path d="M-602 402.9c-1.5 1.7-3.7 2.7-6 2.7-.6 0-1 .4-1 1s.4 1 1 1c2.9 0 5.6-1.2 7.5-3.4.4-.4.3-1-.1-1.4-.4-.3-1.1-.3-1.4.1zm14.1 13.4l-9.6-9.6c2.1-2.5 3.4-5.7 3.4-9.2 0-7.7-6.3-14-14-14s-13.9 6.4-13.9 14.1c0 7.7 6.3 14 14 14 3.5 0 6.7-1.3 9.2-3.4l9.6 9.6c.2.2.5.3.7.3s.5-.1.7-.3c.3-.4.3-1.1-.1-1.5zm-20.1-6.7c-6.6 0-12-5.4-12-12s5.4-12 12-12 12 5.4 12 12-5.4 12-12 12z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-edit--favorites">
        <path d="M17.7 6.2l-5 5-1 3.1 3.1-1 5-5-2.1-2.1zm-3.4 6.3l-1 .3.3-1 4.2-4.2.7.7-4.2 4.2zm-1.1-3.8L9 8.1 7.1 4.3 5.3 8.1l-4.2.6 3 3-.7 4.2 3.8-2 3.8 2-.7-4.2 2.9-3zm-6.1 4L4.7 14l.5-2.7-2-1.9L5.9 9l1.2-2.5L8.3 9l2.7.4-2 1.9.6 2.7-2.5-1.3z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-edit--gallery">
        <path d="M21 9.3l-2.2-2.1L16 9.9V5H2v11h14v-1.8l5-4.9zm-1.3 0l-4.2 4.2-1 .3.3-1L19 8.6l.7.7zM3 6h12v4.9l-1.2 1.3v.1l-1.7-2.1-1.9 2-3.1-4L3 12.7V6zm0 8h.4l3.7-4.2 3 4.1 2-2.1 1.4 1.7L13 15H3v-1zm11.1 1l1.1-.4v.4h-1.1z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-edit--post">
        <path d="M13 8H6v1h7V8zm0 2H6v1h7v-1zm-7 3h4v-1H6v1zm10.8-4.8L15 9.9V4H4v14h11v-3.8l3.9-3.9-2.1-2.1zM14 17H5V5h9v5.9l-2.2 2.3-1 3.1 3.1-1 .1-.2V17zm-.6-2.5l-1 .3.3-1 4.2-4.2.7.7-4.2 4.2z"
        />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-enter-fullscreen">
        <path d="M6.425 10.165l-2.57 2.569.018-1.846c-.003-.552-.45-1-1.002-1.002a.985.985 0 0 0-.992.992l-.023 4.22a1 1 0 0 0 .295.707l.025.023c.008.007.015.017.023.025.188.188.443.294.707.295l4.22-.023a.986.986 0 0 0 .992-.992c-.003-.55-.45-1-1.002-1.002l-1.847.016 2.57-2.569a.99.99 0 0 0 0-1.4l-.013-.013a.99.99 0 0 0-1.4 0h-.001zm7.729-4.899l-.017 1.846c.003.552.45 1 1.002 1.002a.985.985 0 0 0 .992-.992l.024-4.22a1.007 1.007 0 0 0-.296-.707l-.025-.023c-.008-.007-.015-.017-.023-.025a1.009 1.009 0 0 0-.707-.295l-4.22.023a.986.986 0 0 0-.991.992c.002.55.45 1 1.002 1.002l1.846-.016-2.569 2.569a.99.99 0 0 0 0 1.4c.4.4 1.026.4 1.413.013l2.57-2.569z"
        />
    </symbol>
    <symbol viewBox="0 0 40 40" id="icon-error">
        <path d="M27.3 22.9L25 25.1c.3-3.1-.6-6.2-2.6-8.7-2.4-3.1-6-5-9.8-5-.6 0-1 .4-1 1s.4 1 1 1c3.1 0 6.2 1.6 8.2 4.2 1.7 2.2 2.4 4.9 2.1 7.5l-2.3-2.3c-.4-.4-1-.4-1.4 0-.4.4-.4 1 0 1.4l4 3.9c.2.2.4.3.7.3s.5-.1.7-.3l4-3.9c.4-.4.4-1 0-1.4-.3-.3-.9-.3-1.3.1zM40 20C40 9 31 0 20 0 8.9 0 0 9 0 20s8.9 20 20 20c4 0 7.7-1.2 10.8-3.1 3.7 1 8.2 2.1 8.2 2.1s-1-4-2.1-8.3C38.8 27.6 40 24 40 20zm-8.7 14.9c-.2 0-.4-.1-.5-.1-.4 0-.8.1-1.1.3C26.8 37 23.4 38 20 38c-9.9 0-18-8.1-18-18S10.1 2 20 2s18 8.1 18 18c0 3.4-1 6.8-2.8 9.7-.3.5-.4 1.1-.2 1.6.5 1.8.9 3.5 1.3 5-1.6-.4-3.4-.9-5-1.4z"
        />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-exit-fullscreen">
        <path d="M14.425 2.165l-2.57 2.569.018-1.846c-.003-.552-.45-1-1.002-1.002a.985.985 0 0 0-.992.992l-.023 4.22a1.007 1.007 0 0 0 .32.73c.008.007.015.017.023.025.188.188.443.294.707.295l4.22-.023a.986.986 0 0 0 .992-.992c-.003-.55-.45-1-1.002-1.002l-1.847.016 2.57-2.569a.99.99 0 0 0 0-1.4l-.013-.013a.99.99 0 0 0-1.4 0h-.001zM6.154 13.266l-.017 1.846c.003.552.45 1 1.002 1.002a.985.985 0 0 0 .992-.992l.024-4.22a1.007 1.007 0 0 0-.32-.73c-.009-.007-.016-.017-.024-.025a1.009 1.009 0 0 0-.707-.295l-4.22.023a.986.986 0 0 0-.991.992c.002.55.45 1 1.002 1.002l1.846-.016-2.569 2.569a.99.99 0 0 0 0 1.4c.4.4 1.026.4 1.413.013l2.57-2.569z"
        />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-fast-forward">
        <path d="M17.569 8.246L7 2a1 1 0 0 0-1 1v1.954L1 2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1l5-2.955V15a1 1 0 0 0 1 1l10.569-6.246a.876.876 0 0 0 0-1.508zM6 10.722l-4 2.364V4.914l4 2.364v3.444zm2 2.364V4.914L14.915 9 8 13.086z"
        />
    </symbol>
    <symbol viewBox="0 0 30 30" id="icon-financials">
        <path d="M4.14 16.28A8.5 8.5 0 0 1 6 7a8.55 8.55 0 0 1 2.68-1.86A9.08 9.08 0 0 1 12 4.47v2A6.11 6.11 0 0 0 9.46 7a6.49 6.49 0 0 0-4 6A6.45 6.45 0 0 0 6 15.5zM17 25.47v-2a6 6 0 0 0 2.51-.47A6.51 6.51 0 0 0 23 14.44l1.84-.78a8.53 8.53 0 0 1-4.55 11.14 8.93 8.93 0 0 1-3.29.67z"
        />
        <path d="M21.89 17.47l-1.46-1.36 3.97-4.26 4.21 3.93-1.37 1.46-2.74-2.56-2.61 2.79zm-16.43.82L.63 15l1.12-1.65 3.19 2.16 1.98-2.91 1.65 1.13-3.11 4.56zm10.71-5.7a3.93 3.93 0 0 0-.88-.59 2.13 2.13 0 0 0-1-.21 1.47 1.47 0 0 0-.93.26 1 1 0 0 0-.32.83.87.87 0 0 0 .33.69 4.25 4.25 0 0 0 .83.53l1.08.52a5.78 5.78 0 0 1 1.08.66 3.4 3.4 0 0 1 .83.94 2.61 2.61 0 0 1 .33 1.36 3.34 3.34 0 0 1-.61 2.09A2.82 2.82 0 0 1 15 20.8V23h-2v-2.13c0-.06-.89-.19-1.44-.41a4.31 4.31 0 0 1-1.35-.87l1.12-1.68a5.83 5.83 0 0 0 1.25.74 3.09 3.09 0 0 0 1.2.25 1.58 1.58 0 0 0 1-.29 1.11 1.11 0 0 0 .33-.88 1 1 0 0 0-.29-.73 4.39 4.39 0 0 0-.82-.62c-.33-.19-.69-.37-1.08-.56a6 6 0 0 1-1.08-.67 3.57 3.57 0 0 1-.84-.91 2.38 2.38 0 0 1-.33-1.29 3.07 3.07 0 0 1 .56-2.08A2.39 2.39 0 0 1 13 9.81V8h2v1.78c0 .08 1 .24 1.38.49a5.19 5.19 0 0 1 1.08.9z"
        />
    </symbol>
    <symbol viewBox="19.5 264.5 27 33" id="icon-geolocation">
        <path d="M33 264.5c-7.5 0-13.5 6-13.5 13.5 0 7.6 6.6 12.6 13.5 19.5 6.9-6.9 13.5-11.9 13.5-19.5 0-7.5-6-13.5-13.5-13.5zm1.6 22.9v-4.6h-3.2v4.6c-4.2-.7-7.5-4-8.2-8.2h4.6V276h-4.6c.7-4.2 4-7.5 8.2-8.2v4.6h3.2v-4.6c4.2.7 7.5 4 8.2 8.2h-4.6v3.2h4.6c-.7 4.2-4 7.5-8.2 8.2z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-get--review">
        <path d="M11 9H4v1h7V9zm-3 2H4v1h4v-1zm10.5-5.7l-2.9 2.2.6.8L18 7v6h1V7l1.7 1.3.6-.8-2.8-2.2zM1 15h5.8l4.2 2.4V15h3V6H1v9zm1-8h11v7h-3v1.6L7.1 14H2V7z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-get--stars">
        <path d="M9 9.1L7.1 5.3 5.3 9.1l-4.2.6 3 3-.7 4.2 3.8-2 3.8 2-.7-4.2 3-3L9 9.1zm.6 5.9l-2.4-1.3L4.7 15l.5-2.7-2-1.9 2.7-.4 1.2-2.5L8.3 10l2.7.4-2 1.9.6 2.7zm7.9-9.7l-2.9 2.2.6.8L17 7v6h1V7l1.7 1.3.6-.8-2.8-2.2z"
        />
    </symbol>
    <symbol viewBox="-632.5 373.5 55 55" id="icon-good-sales">
        <path d="M-598 397v6h-8v5h-8v5h-8v10h34v-26h-10zm-16 24h-6v-6h6v6zm8 0h-6v-11h6v11zm8 0h-6v-16h6v16zm8 0h-6v-22h6v22zm-19.9-29.7l4.9 5.1 14-14v2.6h2l-.1-6h-5.8v2h2.4l-12.5 12.5-4.9-5.1-10.8 10.9 1.4 1.4 9.4-9.4z"
        />
    </symbol>
    <symbol viewBox="0 0 50 50" id="icon-info">
        <path d="M25 32.3c-2.4 0-4.3 1.9-4.3 4.3s1.9 4.3 4.3 4.3 4.3-1.9 4.3-4.3-1.9-4.3-4.3-4.3zm21.6-21.1l-7.8-7.8c-2-1.9-5.5-3.4-8.3-3.4H19.4c-2.7 0-6.3 1.5-8.2 3.4l-7.8 7.8c-2 2-3.4 5.5-3.4 8.2v11.1c0 2.7 1.5 6.3 3.4 8.2l7.8 7.8c1.9 1.9 5.5 3.4 8.2 3.4h11.1c2.7 0 6.3-1.5 8.2-3.4l7.8-7.8c1.9-1.9 3.4-5.5 3.4-8.2V19.4c.1-2.7-1.4-6.2-3.3-8.2zM46 30.5c0 1.7-1.1 4.2-2.2 5.4L36 43.7c-1.2 1.2-3.7 2.2-5.4 2.2H19.4c-1.7 0-4.2-1.1-5.4-2.2l-7.8-7.8C5 34.8 4 32.2 4 30.5V19.4c0-1.7 1.1-4.2 2.2-5.4L14 6.2C15.2 5 17.8 4 19.4 4h11.1c1.7 0 4.2 1.1 5.4 2.2l7.8 7.8c1.2 1.2 2.2 3.7 2.2 5.4v11.1zm-23.7-.9h5.3l2-18.9h-9.3l2 18.9z"
        />
    </symbol>
    <symbol viewBox="-632.3 373.3 55 55" id="icon-lens">
        <path d="M-602 402.9c-1.5 1.7-3.7 2.7-6 2.7-.6 0-1 .4-1 1s.4 1 1 1c2.9 0 5.6-1.2 7.5-3.4.4-.4.3-1-.1-1.4-.4-.3-1.1-.3-1.4.1zm14.1 13.4l-9.6-9.6c2.1-2.5 3.4-5.7 3.4-9.2 0-7.7-6.3-14-14-14s-13.9 6.4-13.9 14.1c0 7.7 6.3 14 14 14 3.5 0 6.7-1.3 9.2-3.4l9.6 9.6c.2.2.5.3.7.3s.5-.1.7-.3c.3-.4.3-1.1-.1-1.5zm-20.1-6.7c-6.6 0-12-5.4-12-12s5.4-12 12-12 12 5.4 12 12-5.4 12-12 12z"
        />
    </symbol>
    <symbol viewBox="-7 377 16 16" id="icon-login">
        <path d="M-7 393v-.9s0-.7.1-1.4c.2-1.1.5-1.9.9-2.4.5-.5 1.4-.8 2.2-1 .4-.1.8-.2 1.1-.3.3-.1.4-.2.5-.3v-.1c.1-.3 0-.6-.5-1.3-.2-.3-.5-.7-.7-1.2-.6-1.4-.7-2.9-.3-4.3.3-.9.9-1.6 1.7-2.1 1-.4 1.9-.7 3-.7s2 .2 2.8.7c.8.5 1.4 1.2 1.7 2.1.4 1.4.3 2.9-.3 4.3-.2.5-.4.8-.7 1.2-.4.7-.6 1-.5 1.3v.1c.1.1.2.2.5.3.3.1.7.2 1.1.3.8.2 1.7.5 2.2 1 .5.5.8 1.2.9 2.4.1.8.1 1.4.1 1.4v.9H-7zm2.3-3.5c-.1.1-.3.5-.4 1.4v.2l.3-.1h12v-.2c-.2-1.1-.4-1.3-.4-1.3-.2-.2-.7-.3-1.5-.5-1.1-.3-2.4-.6-2.8-1.7-.5-1.2.1-2.2.6-2.9.2-.3.4-.6.5-.9.4-1.1.5-2.1.2-3.1-.4-1.4-1.9-1.6-2.8-1.6s-2.3.2-2.8 1.6c-.3 1-.2 2 .2 3.1.1.3.3.6.5.9.5.8 1.1 1.7.6 2.9-.4 1-1.7 1.4-2.8 1.7-.7.2-1.2.3-1.4.5z"
        />
    </symbol>
    <symbol viewBox="0 0 22 16" id="icon-mail">
        <path d="M0 0v16h22V0H0zm11 8.7L3.6 2h14.8L11 8.7zM6.8 7.5l-4.8 5V3.2l4.8 4.3zm1.5 1.4l2.7 2.5 2.7-2.5 4.9 5.1H3.3l5-5.1zm6.9-1.4L20 3.2v9.3l-4.8-5z"
        />
    </symbol>
    <symbol viewBox="0 0 34 47" id="icon-marker">
        <path fill="#0BA" d="M17 0C7.6 0 0 7.6 0 17s12.1 25.1 17 30c4.5-4.5 17-20.6 17-30 0-9.4-7.6-17-17-17zm0 23c-3 0-5.5-2.5-5.5-5.5S14 12 17 12s5.5 2.5 5.5 5.5S20 23 17 23z"
        />
        <linearGradient id="bxa" gradientUnits="userSpaceOnUse" x1="8.5" x2="8.5" y2="47">
            <stop offset="0" stop-color="#00d9c8" />
            <stop offset="1" stop-color="#00937d" />
        </linearGradient>
        <path fill="url(#bxa)" d="M11.5 17.5c0-3 2.5-5.5 5.5-5.5V0C7.6 0 0 7.6 0 17s12.1 25.1 17 30V23c-3 0-5.5-2.5-5.5-5.5z"
        />
        <linearGradient id="bxb" gradientUnits="userSpaceOnUse" x1="17" y1="28" x2="17" y2="7">
            <stop offset="0" stop-color="#00d9c8" />
            <stop offset="1" stop-color="#00937d" />
        </linearGradient>
        <path fill="url(#bxb)" d="M17 7C11.2 7 6.5 11.7 6.5 17.5S11.2 28 17 28s10.5-4.7 10.5-10.5S22.8 7 17 7zm0 16c-3 0-5.5-2.5-5.5-5.5S14 12 17 12s5.5 2.5 5.5 5.5S20 23 17 23z"
        />
    </symbol>
    <symbol viewBox="0 0 34 47" id="icon-marker-white">
        <path fill="#f6f6f6" d="M17 0C7.6 0 0 7.6 0 17s12.1 25.1 17 30c4.5-4.5 17-20.6 17-30 0-9.4-7.6-17-17-17zm0 23c-3 0-5.5-2.5-5.5-5.5S14 12 17 12s5.5 2.5 5.5 5.5S20 23 17 23z"
        />
        <linearGradient id="bya" gradientUnits="userSpaceOnUse" x1="8.5" x2="8.5" y2="47">
            <stop offset="0" stop-color="#f6f6f6" />
            <stop offset="1" stop-color="#d0d0d0" />
        </linearGradient>
        <path fill="url(#bya)" d="M11.5 17.5c0-3 2.5-5.5 5.5-5.5V0C7.6 0 0 7.6 0 17s12.1 25.1 17 30V23c-3 0-5.5-2.5-5.5-5.5z"
        />
        <linearGradient id="byb" gradientUnits="userSpaceOnUse" x1="17" y1="28" x2="17" y2="7">
            <stop offset="0" stop-color="#f6f6f6" />
            <stop offset="1" stop-color="#d0d0d0" />
        </linearGradient>
        <path fill="url(#byb)" d="M17 7C11.2 7 6.5 11.7 6.5 17.5S11.2 28 17 28s10.5-4.7 10.5-10.5S22.8 7 17 7zm0 16c-3 0-5.5-2.5-5.5-5.5S14 12 17 12s5.5 2.5 5.5 5.5S20 23 17 23z"
        />
    </symbol>
    <symbol preserveAspectRatio="xMidYMid" viewBox="0 0 30 30" id="icon-menu">
        <path class="bzcls-1" d="M1 21h28v3H1zm0-7h28v3H1zm0-7h28v3H1z" />
    </symbol>
    <symbol preserveAspectRatio="xMidYMid" viewBox="0 0 30 30" id="icon-menu-close">
        <path d="M6.162 4.539l19.799 19.799-2.121 2.121L4.041 6.66l2.121-2.121z" class="cacls-1" />
        <path d="M4.039 24.338L23.838 4.539l2.122 2.122L6.161 26.46l-2.122-2.122z" class="cacls-1" />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-muted">
        <path d="M9.214 2a.62.62 0 0 0-.334.101l-4.048 2.81A.494.494 0 0 1 4.549 5H.996A.998.998 0 0 0 0 6v6c0 .552.446 1 .996 1h3.553c.102 0 .2.031.283.089l4.048 2.81a.62.62 0 0 0 .334.101c.392 0 .747-.4.747-.949V2.95c0-.55-.355-.949-.747-.949V2zM7.969 12.834l-2.387-1.657a.996.996 0 0 0-.566-.178H2.491a.5.5 0 0 1-.498-.5v-3a.5.5 0 0 1 .498-.5h2.525c.202 0 .4-.062.566-.178l2.387-1.657v7.67zm6.965-4.035c-.086-1.748-1.514-2.991-2.507-3.649-.47-.312-1.094-.122-1.325.408l-.038.086a.973.973 0 0 0 .336 1.194c.706.473 1.586 1.247 1.624 2.065.032.676-.553 1.468-1.663 2.27a.987.987 0 0 0-.285 1.275l.042.075c.266.475.866.624 1.3.312 1.74-1.251 2.586-2.606 2.516-4.037v.001z"
        />
        <path d="M13.957 9.2c.086 1.747 1.514 2.99 2.507 3.648.47.312 1.094.122 1.325-.408l.038-.086a.973.973 0 0 0-.336-1.194c-.706-.473-1.586-1.247-1.624-2.065-.032-.676.553-1.468 1.663-2.27a.987.987 0 0 0 .285-1.275l-.042-.075c-.266-.475-.866-.624-1.3-.312-1.74 1.251-2.586 2.606-2.516 4.037z"
        />
    </symbol>
    <symbol viewBox="0 0 30 30" id="icon-news">
        <path d="M24 23H5V7h19v16zM7 21h15V9H7v12z" />
        <path d="M8 10h6v5H8zm8 0h5v2h-5zm0 5h5v1h-5zm-8 2h13v1H8zm0 2h13v1H8z" />
    </symbol>
    <symbol viewBox="0 0 42 33" id="icon-noitems">
        <path d="M38.5 0h-35C1.6 0 0 1.6 0 3.5v26C0 31.4 1.6 33 3.5 33h35c1.9 0 3.5-1.6 3.5-3.5v-26C42 1.6 40.4 0 38.5 0zm.5 29.5c0 .3-.2.5-.5.5h-35c-.3 0-.5-.2-.5-.5v-26c0-.3.2-.5.5-.5h35c.3 0 .5.2.5.5v26zM7 10h27V7H7v3zm0 6h27v-3H7v3zm0 6h18v-3H7v3z"
        />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-pause">
        <path d="M2 4v10c0 2 2 2 2 2h2s2 0 2-2V4c0-2-2-2-2-2H4S2 2 2 4zm2 0h2v10H4V4zm6 0v10c0 2 2 2 2 2h2s2 0 2-2V4c0-2-2-2-2-2h-2s-2 0-2 2zm2 0h2v10h-2V4z"
        />
    </symbol>
    <symbol viewBox="0 0 14 14" id="icon-phone">
        <path d="M10.922 14.004a3.503 3.503 0 0 1-1.03-.151 7.814 7.814 0 0 1-.474-.145c-.108-.038-.304-.111-.586-.216a18.755 18.755 0 0 0-.546-.2 9.275 9.275 0 0 1-1.759-.835c-.877-.541-1.798-1.293-2.74-2.235-.942-.941-1.693-1.863-2.233-2.737a9.23 9.23 0 0 1-.84-1.774 38.255 38.255 0 0 0-.196-.533 43.438 43.438 0 0 1-.217-.587 8.621 8.621 0 0 1-.145-.474 4.185 4.185 0 0 1-.118-.542 3.715 3.715 0 0 1-.032-.488c0-.562.161-1.144.48-1.731C.941.534 1.242.34 1.349.294c.156-.068.369-.133.645-.196.321-.074.512-.092.618-.093.053.071.152.225.31.54.093.163.198.352.331.597.137.253.263.482.379.688.117.208.231.405.341.588l.015.025.016.022c.021.027.079.111.177.252.108.157.161.252.186.305a.282.282 0 0 1 .014.035 1.056 1.056 0 0 1-.146.183 4.747 4.747 0 0 1-.595.528c-.26.194-.503.402-.723.617-.203.2-.472.509-.472.891 0 .133.029.275.088.435.045.121.084.213.115.275.029.059.087.16.175.302.06.097.097.158.109.18.567 1.022 1.227 1.912 1.962 2.647.734.735 1.625 1.395 2.646 1.961.027.015.086.051.181.11.142.088.243.146.301.175.063.032.155.071.277.115.159.06.301.089.434.089.383 0 .692-.27.891-.473.218-.222.426-.465.618-.723a4.74 4.74 0 0 1 .527-.594c.092-.087.152-.129.184-.147.009.002.02.007.034.014.052.025.148.078.306.187.141.097.224.155.251.175l.023.018.024.014c.184.111.38.224.589.341.205.115.435.242.687.38.246.132.434.237.567.314.338.17.498.273.57.326a3.021 3.021 0 0 1-.093.619 3.764 3.764 0 0 1-.192.635c-.049.116-.244.417-1.07.875-.583.316-1.165.478-1.727.478z"
              class="chcls-1" />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-play">
        <path d="M5 4.914L11.915 9 5 13.086V4.914zM4 2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1l10.569-6.246a.876.876 0 0 0 0-1.508L4 2z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-remove--favorites">
        <path d="M15.7 9.2l.5-.5-4.2-.6-1.9-3.8-1.8 3.8-4.2.6 3 3-.7 4.2 3.8-2 1.7.9c.6.8 1.6 1.3 2.7 1.3 1.9 0 3.5-1.6 3.5-3.5C18 11 17 9.7 15.7 9.2zM11 12.5c0 .2 0 .5.1.7l-.9-.5L7.7 14l.5-2.7-2-1.9L8.9 9l1.2-2.5L11.3 9l1.8.3c-1.2.5-2.1 1.7-2.1 3.2zm3.5 2.5c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.2 2.5-2.5 2.5zM13 13h3v-1h-3v1z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-remove--gallery">
        <path d="M17.5 8c-.5 0-1 .1-1.5.3V5H2v11h14v-1.3c.4.2.9.3 1.5.3 1.9 0 3.5-1.6 3.5-3.5S19.4 8 17.5 8zM3 6h12v3c-.6.6-1 1.5-1 2.5 0 .5.1 1 .4 1.5h-.1L12 10.2l-1.9 2-3.1-4-4 4.5V6zm12 9H3v-1h.2l3.7-4.2 3 4.1 2-2.1 1.9 2.2H15v1zm2.5-1c-1.4 0-2.5-1.1-2.5-2.5S16.1 9 17.5 9s2.5 1.1 2.5 2.5-1.2 2.5-2.5 2.5zM16 12h3v-1h-3v1z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-remove--post">
        <path d="M12 8H5v1h7V8zm0 2H5v1h7v-1zm-7 3h4v-1H5v1zm10.5-3c-.5 0-1.5.1-1.5.3V4H3v14h11v-1.3c0 .2 1 .3 1.5.3 1.9 0 3.5-1.6 3.5-3.5S17.4 10 15.5 10zM13 17H4V5h9v6c-1 .6-1 1.5-1 2.5s0 1.9 1 2.5v1zm2.5-1c-1.4 0-2.5-1.1-2.5-2.5s1.1-2.5 2.5-2.5 2.5 1.1 2.5 2.5-1.1 2.5-2.5 2.5zM14 14h3v-1h-3v1z"
        />
    </symbol>
    <symbol viewBox="0 0 22 22" id="icon-remove--property">
        <path d="M17.5 3c-2 0-3.5 1.6-3.5 3.5s1.6 3.5 3.5 3.5S21 8.4 21 6.5 19.4 3 17.5 3zm0 6C16.1 9 15 7.9 15 6.5S16.1 4 17.5 4 20 5.1 20 6.5 18.8 9 17.5 9zM16 7h3V6h-3v1zM.7 11.6l.5.8L4 10.7V16h10v-5.3l2.7 1.7.5-.8L9 6.4.7 11.6zM13 10.1V15H5v-4.9l4-2.5 4 2.5z"
        />
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-restart">
        <path d="M1 2a1 1 0 0 1 1 1v4.318L11 2a1 1 0 0 1 1 1v1.954L17 2a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1l-5-2.955V15a1 1 0 0 1-1 1l-9-5.318V15a1 1 0 0 1-2 0V3a1 1 0 0 1 1-1zm11 8.722l4 2.364V4.914l-4 2.364v3.444zm-2 2.364V4.914L3.085 9 10 13.086z"
        />
    </symbol>
    <symbol viewBox="0 0 18 21" id="icon-rewind">
        <path d="M.431 10.754L11 17a1 1 0 0 0 1-1v-1.954L17 17a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1l-5 2.955V4a1 1 0 0 0-1-1L.431 9.246a.876.876 0 0 0 0 1.508zM12 8.278l4-2.364v8.172l-4-2.364V8.278zm-2-2.364v8.172L3.085 10 10 5.914z"
        />
    </symbol>
    <symbol viewBox="0 0 30 30" id="icon-statistics">
        <path d="M25 23H4V8h1v14h20v1z" />
        <path d="M7 20h4v2H7zm6-4h4v6h-4zm6-4h4v10h-4z" />
    </symbol>
    <symbol viewBox="0 0 40 40" id="icon-transactions">
        <path d="M28 10V3H12v7H1v27h38V10H28zM14 5h12v5H14V5zm23 7v7H3v-7h34zm-19 9h4v4h-4v-4zM3 35V21h13v6h8v-6h13v14H3z" />
    </symbol>
    <symbol viewBox="-7 377 16 16" id="icon-user">
        <path d="M-7 393v-.9s0-.7.1-1.4c.2-1.1.5-1.9.9-2.4.5-.5 1.4-.8 2.2-1 .4-.1.8-.2 1.1-.3.3-.1.4-.2.5-.3v-.1c.1-.3 0-.6-.5-1.3-.2-.3-.5-.7-.7-1.2-.6-1.4-.7-2.9-.3-4.3.3-.9.9-1.6 1.7-2.1 1-.4 1.9-.7 3-.7s2 .2 2.8.7c.8.5 1.4 1.2 1.7 2.1.4 1.4.3 2.9-.3 4.3-.2.5-.4.8-.7 1.2-.4.7-.6 1-.5 1.3v.1c.1.1.2.2.5.3.3.1.7.2 1.1.3.8.2 1.7.5 2.2 1 .5.5.8 1.2.9 2.4.1.8.1 1.4.1 1.4v.9H-7zm2.3-3.5c-.1.1-.3.5-.4 1.4v.2l.3-.1h12v-.2c-.2-1.1-.4-1.3-.4-1.3-.2-.2-.7-.3-1.5-.5-1.1-.3-2.4-.6-2.8-1.7-.5-1.2.1-2.2.6-2.9.2-.3.4-.6.5-.9.4-1.1.5-2.1.2-3.1-.4-1.4-1.9-1.6-2.8-1.6s-2.3.2-2.8 1.6c-.3 1-.2 2 .2 3.1.1.3.3.6.5.9.5.8 1.1 1.7.6 2.9-.4 1-1.7 1.4-2.8 1.7-.7.2-1.2.3-1.4.5z"
        />
    </symbol>
    <symbol viewBox="0 0 30 30" id="icon-user-admin">
        <path d="M6.94 23.25v-.88a12.22 12.22 0 0 1 .13-1.43A4.24 4.24 0 0 1 8 18.57a5 5 0 0 1 2.25-1 11.12 11.12 0 0 0 1.12-.34 1.61 1.61 0 0 0 .5-.28v-.06a1.55 1.55 0 0 0-.49-1.28 7.65 7.65 0 0 1-.68-1.19 6.12 6.12 0 0 1-.26-4.29A3.82 3.82 0 0 1 12.22 8 5.3 5.3 0 0 1 15 7.25a5.3 5.3 0 0 1 2.78.75 3.82 3.82 0 0 1 1.66 2.13 6.12 6.12 0 0 1-.26 4.29 7.66 7.66 0 0 1-.68 1.19 1.55 1.55 0 0 0-.5 1.25v.06a1.61 1.61 0 0 0 .5.28 11.11 11.11 0 0 0 1.12.34 5 5 0 0 1 2.25 1 4.24 4.24 0 0 1 .94 2.37 12.22 12.22 0 0 1 .19 1.46v.88H6.94zm2.28-3.43a3.27 3.27 0 0 0-.43 1.41v.3h12.46v-.33a2.89 2.89 0 0 0-.45-1.42 4.35 4.35 0 0 0-1.47-.54c-1.12-.3-2.39-.64-2.82-1.68a3 3 0 0 1 .62-2.93 6.14 6.14 0 0 0 .53-.92 4.37 4.37 0 0 0 .2-3.1A2.71 2.71 0 0 0 15 9a2.71 2.71 0 0 0-2.81 1.64 4.37 4.37 0 0 0 .2 3.1 6.14 6.14 0 0 0 .53.92 3 3 0 0 1 .62 2.93c-.44 1-1.7 1.38-2.82 1.68a4.33 4.33 0 0 0-1.47.54z"
        />
    </symbol>
    <symbol viewBox="0 0 40 40" id="icon-valid">
        <path d="M24.7 10.3c-.4-.4-1-.4-1.4 0l-4 4c-.4.4-.4 1 0 1.4.4.4 1 .4 1.4 0l2.3-2.3c.3 2.8-.5 5.7-2.3 8-2 2.6-5 4.1-8 4.1-.6 0-1 .4-1 1s.4 1 1 1c3.6 0 7.2-1.8 9.6-4.9 2.1-2.7 3-5.9 2.7-9.2l2.3 2.3c.2.2.5.3.7.3.3 0 .5-.1.7-.3.4-.4.4-1 0-1.4l-4-4zM40 20C40 9 31 0 20 0S0 9 0 20s8.9 20 20 20c4 0 7.7-1.2 10.8-3.1 3.7 1 8.2 2.1 8.2 2.1s-1-4-2.1-8.3C38.8 27.6 40 24 40 20zm-8.7 14.9c-.2 0-.4-.1-.5-.1-.4 0-.8.1-1.1.3C26.8 37 23.4 38 20 38c-9.9 0-18-8.1-18-18S10.1 2 20 2s18 8.1 18 18c0 3.4-1 6.8-2.8 9.7-.3.5-.4 1.1-.2 1.6.5 1.8.9 3.5 1.3 5-1.6-.4-3.4-.9-5-1.4z"
        />
        <symbol preserveAspectRatio="xMidYMid" viewBox="0 0 28 28.03" id="icon-video">
            <path d="M26.34 13.885c-.477 0-.964.204-1.452.613l-3.89 3.307v-.46c0-1.626-1.135-3.37-2.828-3.37H6c-2.506 0-4 1.492-4 3.99v6.018c0 2.552 1.42 3.96 4 3.96h12.17c1.772 0 2.83-.935 2.83-2.5v-1.332l3.94 3.304c.482.408.966.614 1.436.614.75 0 1.623-.544 1.623-2.08V15.97c0-1.44-.834-2.085-1.66-2.085zM26 25.695l-3.8-3.184c-.475-.4-.986-.613-1.478-.613-.83 0-1.723.65-1.723 2.08v1.467c0 .29 0 .503-.83.503H6c-1.477 0-2-.514-2-1.964v-6.017c0-1.417.578-1.995 2-1.995h12.17c.403 0 .83.708.83 1.376v.53c0 1.433.916 2.085 1.77 2.085.5 0 1.015-.208 1.497-.61L26 16.173v9.522zM9 7.49c0-2.474-2.02-4.488-4.5-4.488C2.017 3.002 0 5.016 0 7.49a4.5 4.5 0 0 0 9 0zm-7 0a2.5 2.5 0 0 1 5 0 2.5 2.5 0 0 1-5 0zm15 4.49c3.308 0 6-2.685 6-5.987 0-3.3-2.692-5.985-6-5.985-3.31 0-6 2.685-6 5.985 0 3.302 2.69 5.987 6 5.987zm0-9.976a4 4 0 0 1 4 3.99 4 4 0 0 1-8 0 4 4 0 0 1 4-3.99zM8 17.966c-1.105 0-2 .893-2 1.995a2 2 0 0 0 4 0 1.997 1.997 0 0 0-2-1.994z"
                  class="bmcls-1" />
        </symbol>
    </symbol>
    <symbol viewBox="0 0 18 18" id="icon-volume">
        <path d="M10.214 2a.62.62 0 0 0-.334.101l-4.048 2.81A.494.494 0 0 1 5.549 5H1.996A.998.998 0 0 0 1 6v6c0 .552.446 1 .996 1h3.553c.102 0 .2.031.283.089l4.048 2.81a.62.62 0 0 0 .334.101c.392 0 .747-.4.747-.949V2.95c0-.55-.355-.949-.747-.949zM8.969 12.834l-2.387-1.657a.996.996 0 0 0-.566-.178H3.491a.5.5 0 0 1-.498-.5v-3a.5.5 0 0 1 .498-.5h2.525c.202 0 .4-.062.566-.178l2.387-1.657v7.669zm7.965-4.035c-.086-1.748-1.514-2.991-2.507-3.649-.47-.312-1.094-.122-1.325.408l-.038.086a.973.973 0 0 0 .336 1.194c.706.473 1.586 1.247 1.624 2.065.032.676-.553 1.468-1.663 2.27a.987.987 0 0 0-.285 1.275l.042.075c.266.475.866.624 1.3.312 1.74-1.251 2.586-2.606 2.516-4.037z"
        />
    </symbol>
    <symbol viewBox="0 0 17 22" id="icon-window">
        <path d="M0 0v22h17V0H0zm15 2v2H2V2h13zM2 10V8h13v2H2zm0-3V5h13v2H2zm0 13v-8h6v2H7v3h3v-3H9v-2h6v8H2z" />
    </symbol>
    <symbol viewBox="0 0 17 31" id="slider-handle">
        <linearGradient id="cya" gradientUnits="userSpaceOnUse" x1="8.5" y1="31" x2="8.5" y2="8">
            <stop offset="0" stop-color="#e4e4e4" stop-opacity="0" />
            <stop offset="1" stop-color="#e4e4e4" />
        </linearGradient>
        <path fill="url(#cya)" d="M0 8h17v23H0z" />
        <linearGradient id="cyb" gradientUnits="userSpaceOnUse" x1="8.5" y1=".5" x2="8.5" y2="16.5">
            <stop offset="0" stop-color="#fff" />
            <stop offset="1" stop-color="#ececec" />
        </linearGradient>
        <path fill="url(#cyb)" d="M8.5 16.5c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z" />
        <path fill="#CACACA" d="M8.5 1C12.6 1 16 4.4 16 8.5S12.6 16 8.5 16 1 12.6 1 8.5 4.4 1 8.5 1m0-1C3.8 0 0 3.8 0 8.5S3.8 17 8.5 17 17 13.2 17 8.5 13.2 0 8.5 0z"
        />
        <path fill="#CBCBCB" d="M6 6h1v5H6zm2 0h1v5H8zm2 0h1v5h-1z" />
    </symbol>
    <symbol viewBox="0 0 17 17" id="slider-handle-2">
        <linearGradient id="cza" gradientUnits="userSpaceOnUse" x1="8.5" y1=".5" x2="8.5" y2="16.5">
            <stop offset="0" stop-color="#fff" />
            <stop offset="1" stop-color="#ececec" />
        </linearGradient>
        <path fill="url(#cza)" d="M8.5 16.5c-4.4 0-8-3.6-8-8s3.6-8 8-8 8 3.6 8 8-3.6 8-8 8z" />
        <path fill="#CACACA" d="M8.5 1C12.6 1 16 4.4 16 8.5S12.6 16 8.5 16 1 12.6 1 8.5 4.4 1 8.5 1m0-1C3.8 0 0 3.8 0 8.5S3.8 17 8.5 17 17 13.2 17 8.5 13.2 0 8.5 0z"
        />
        <path fill="#CBCBCB" d="M6 6h1v5H6zm2 0h1v5H8zm2 0h1v5h-1z" />
    </symbol>
</svg>
<!-- End SVG icon definitions -->

<!-- TOP LEVEL CONTAINER -->
<div class="box js-box">

    <!-- TOP BAR -->
    <header class="header header--brand">
        <div class="container">
            <div class="header__row">
                <a href="<?php echo get_site_url(); ?>/" class="header__logo">
                    <img src="<?php echo get_template_directory_uri(); ?>/img/logo-mob.png" alt="<?php bloginfo('name'); ?>">

                    <!-- DONATE BUTTON -->
                    <div class="header__donate_button">
                        <a href="<?php echo get_site_url(); ?>/" class="button__default button__default--normal button__default_donate">Donate</a>
                    </div>

                    <!-- TOP BAR SOCIAL ICONS -->
                    <div class="header__social">
                        <div class="social social--header social--circles"><a href="<?php echo get_site_url(); ?>/" class="social__item"><i class="fa fa-facebook"></i></a><a href="<?php echo get_site_url(); ?>/" class="social__item"><i class="fa fa-twitter"></i></a>
                            <a
                                href="<?php echo get_site_url(); ?>/" class="social__item"><i class="fa fa-google-plus"></i></a>
                        </div>
                    </div>

                    <!-- MOBILE MENU -->
                    <button type="button" class="header__navbar-toggle js-navbar-toggle">
                        <svg class="header__navbar-show">
                            <use xlink:href="#icon-menu"></use>
                        </svg>
                        <svg class="header__navbar-hide">
                            <use xlink:href="#icon-menu-close"></use>
                        </svg>
                    </button>
            </div>
        </div>
    </header>

    <!-- MAIN SITE NAVIGATION-->
    <div id="header-nav-offset"></div>
    <nav id="header-nav" class="navbar navbar--header">
      <div class="container">
        <div class="navbar__row js-navbar-row">
          <a href="<?php echo get_site_url(); ?>/" class="navbar__brand">
            <img src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="<?php bloginfo('name'); ?>">
            </a>
            <div id="navbar-collapse-1" class="navbar__wrap">
              <ul class="navbar__nav">
                <li class="navbar__item js-dropdown active"><a href="<?php echo get_site_url(); ?>/" class="navbar__link">Home</a></li>
                <li class="navbar__item js-dropdown"><a href="<?php echo get_site_url(); ?>/" class="navbar__link">About us</a>
                </li>
                <li class="navbar__item js-dropdown"><a class="navbar__link">Members
                    <svg class="navbar__arrow">
                      <use xlink:href="#icon-arrow-right"></use>
                    </svg></a>
                  <div role="menu" class="js-dropdown-menu navbar__dropdown">
                    <button class="navbar__back js-navbar-submenu-back">
                      <svg class="navbar__arrow">
                        <use xlink:href="#icon-arrow-left"></use>
                      </svg>Back
                    </button>
                    <div class="navbar__submenu">
                      <ul class="navbar__subnav">
                        <li class="navbar__subitem"><a href="<?php echo get_site_url(); ?>/" class="navbar__sublink js-navbar-sub-sublink">Members' profiles 1</a></li>
                        <li class="navbar__subitem navbar__subitem-dropdown js-dropdown"><a href="<?php echo get_site_url(); ?>/" class="navbar__sublink js-navbar-sublink">Members' profiles 2
                            <svg class="navbar__arrow">
                              <use xlink:href="#icon-arrow-right"></use>
                            </svg></a>
                          <div class="navbar__submenu navbar__submenu--level">
                            <button class="navbar__back js-navbar-submenu-back">
                              <svg class="navbar__arrow">
                                <use xlink:href="#icon-arrow-left"></use>
                              </svg>Back
                            </button>
                            <ul class="navbar__subnav">
                              <li class="navbar__subitem"><a href="<?php echo get_site_url(); ?>/" class="navbar__sublink js-navbar-sub-sublink">Member 1</a></li>
                              <li class="navbar__subitem"><a href="<?php echo get_site_url(); ?>/" class="navbar__sublink js-navbar-sub-sublink">Member 2</a></li>
                              <li class="navbar__subitem"><a href="<?php echo get_site_url(); ?>/" class="navbar__sublink js-navbar-sub-sublink">Member 3</a></li>
                              <li class="navbar__subitem"><a href="<?php echo get_site_url(); ?>/" class="navbar__sublink js-navbar-sub-sublink">Member 4</a></li>
                            </ul>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </li>
                <li class="navbar__item js-dropdown"><a href="<?php echo get_site_url(); ?>/" class="navbar__link">Blog</a>
                </li>
                <li class="navbar__item js-dropdown"><a href="<?php echo get_site_url(); ?>/" class="navbar__link">Gallery</a>
                </li>
                <li class="navbar__item js-dropdown"><a href="<?php echo get_site_url(); ?>/" class="navbar__link">Testimonials</a>
                </li>
                <li class="navbar__item"><a href="<?php echo get_site_url(); ?>/" class="navbar__link">Contact</a></li>
              </ul>
            </div>
        </div>
      </div>
    </nav>
