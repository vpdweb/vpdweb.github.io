$(document).ready(function() {

    /*
     Slick slider functionality
     */
    $('#main_slider, #testimonial_slider').slick({
        dots: true,
        autoplay: true,
        autoplaySpeed: 3000
    });

    $('#partners_slider').slick({
        autoplay: true,
        autoplaySpeed: 3000,
        slidesToShow: 6,
        slidesToScroll: 1,
        prevArrow: $('.partners__arrow--prev'),
        nextArrow: $('.partners__arrow--next')
    });

    /*
     Helper function for the jquery countdown plugin.
     It has been used here to display countdown for the next event component on the homepage.
     */
    var endDate = $("div#clock").data("end-date");
    var date_template = '<div class="countdown__column"> \
	                <div class="countdown__value">%D</div> \
	                <div class="countdown__label">Days</div> \
	              </div>\
	              <div class="countdown__delimiter"></div> \
	              <div class="countdown__column"> \
	                <div class="countdown__value">%H</div> \
	                <div class="countdown__label">Hours</div> \
	              </div> \
	              <div class="countdown__delimiter"></div> \
	              <div class="countdown__column"> \
	                <div class="countdown__value">%M</div> \
	                <div class="countdown__label">Minutes</div> \
	              </div> \
	              <div class="countdown__delimiter countdown__delimiter--seconds"></div> \
	              <div class="countdown__column"> \
	                <div class="countdown__value">%S</div> \
	                <div class="countdown__label">Seconds</div> \
	              </div>';

    $("div#clock").countdown(endDate, function (event) {
        $(this).html(event.strftime(date_template));
    });

    /*
    Helper function for the scroll trigger animations script
    */

    var trigger = new ScrollTrigger({
        addHeight: true,
        once: true
    });

    /*
    Helper function for the scroll-up effect
    */
    var $scrollup = $('.js-scrollup'),
        scrollupClass = '',
        _cssClass = null;

    $(window).scroll(function () {
        var offsetTop = $(window).scrollTop();
        if (offsetTop > 400) {
            scrollupClass = 'scrollup-show';
        } else {
            scrollupClass = '';
        }

        if (scrollupClass !== _cssClass) {
            $scrollup.removeClass('scrollup-show');
            $scrollup.addClass(scrollupClass);
            _cssClass = scrollupClass;
        }
    });

    $scrollup.on('click', function () {
        var offsetTop = $(window).scrollTop();
        var time = 800 + (offsetTop / 10);
        $('html, body').animate({scrollTop: 0}, time, 'linear');
    });

});