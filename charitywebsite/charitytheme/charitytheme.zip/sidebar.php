<?php
/*
Add code to go to a sidebar widget area of any page or post template you make
*/
?>